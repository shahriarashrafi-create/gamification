# Update 20 — Compact Settings & Focus Sound Pack

- ارتفاع Backup کمتر شد و همه توضیحات آن حذف شد؛ فقط Import و Export باقی ماند.
- Appearance کوتاه شد و فقط Day/Night دارد.
- ساعت شروع روز از Appearance جدا و در کارت مستقل قرار گرفت.
- Sound Card کوتاه و مرتب شد.
- آیکن روشن/خاموش صدا کنار عنوان «صدای بازی» قرار گرفت.
- Test Effect حذف شد.
- عنوان «صدای ۲۵ دقیقه‌ای» و توضیحات اضافه حذف شدند.
- Volume در ردیف مستقل قرار گرفت تا هیچ تداخلی با Sound Picker نداشته باشد.
- نسخه و متن‌های Branding/Discipline از Settings حذف شدند.
- سه حالت موج دریا + Piano + Forest + Fire + Cafe + Meditation به صداهای قبلی اضافه شد.
- مجموع حالت‌های Focus Sound به ۱۲ رسید.
- تغییر صدا یا Volume وسط Focus تایمر را ریست نمی‌کند.
- بکاپ، روز/شب، شروع روز، Combo، Rank، Vault و Achievements حفظ شده‌اند.
