# Final Review — v2.20.0

- Backup card reduced to only Import / Export.
- Appearance card reduced to only Day / Night.
- Game-day start time is a separate compact card.
- Sound card reduced; power icon sits beside the main sound title.
- Removed Test Effect, app version text, branding/discpline text and the “25 minute sound” heading.
- Volume has its own row and does not overlap the sound picker.
- 12 focus sound modes are available, including three ocean variants, piano, forest, fire, cafe and meditation.
- Focus audio keeps running through Android Foreground Media Service.
- Dark and Light settings layouts were tested at 360×740, 390×844 and 708×1536 with zero control overlaps.
- Return-to-first task was retested; no persistent blur/filter/inline transform remains.
- Game-day boundary at 06:00 was retested (05:59 stays previous day; 06:00 starts next day).
