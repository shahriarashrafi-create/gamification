# Billionaires Action — v2.20.0

نسخه ۲۰ با تنظیمات جمع‌وجورتر، صداهای تمرکز بیشتر، Quest Deck، XP/Rank/Combo، Focus ×2، صندوق‌های روزانه/هفتگی/ماهانه، دستاوردها، Backup و Day/Night.

## تنظیمات v20
- Backup فقط با دو دکمه `Export` و `Import`.
- ظاهر فقط با `روز` و `شب`.
- ساعت شروع روز در کارت مستقل.
- صدای بازی با آیکن روشن/خاموش کنار عنوان.
- حذف Test Effect و متن‌های توضیحی اضافه.
- شدت صدا در ردیف جدا و بدون تداخل با انتخاب صدا.

## صداهای Focus
- Flow
- Pulse
- Rain
- Arcade
- موج آرام
- موج عمیق
- ساحل شب
- پیانو
- جنگل
- آتش
- کافه
- مدیتیشن

همه صداهای Focus هنگام تایمر ۲۵ دقیقه‌ای در Foreground Media Service پخش می‌شوند و در پس‌زمینه ادامه دارند.

## ساخت APK
GitHub Actions خروجی زیر را می‌سازد:

`Gamification-v2.20-CompactSettings.apk`
