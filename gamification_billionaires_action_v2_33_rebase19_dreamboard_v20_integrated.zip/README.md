# Billionaires Action — v2.21.0 (rebased on v2.19)

نسخه ۱۹ با Quest Deck، Rank مبتنی بر R، XP، Combo یک‌ساعته، Focus 25 دقیقه‌ای ×2، صندوق‌های جایزه، دستاوردها، تنظیمات، Backup، Day/Night و Game Audio.

## صندوق
- روزانه: 4 / 7 / 10 / 15 / 20 اقدام
- هفتگی: 20 / 35 / 50 / 75 / 100 اقدام
- ماهانه: 80 / 150 / 250 / 400 / 600 اقدام
- صندوق آماده را لمس کن تا XP آن دریافت شود.

## روز بازی
روز به‌صورت پیش‌فرض ساعت 06:00 شروع می‌شود. تا قبل از 06:00، تسک‌های روز قبل همچنان فعال هستند. ساعت شروع روز از تنظیمات قابل تغییر است.

## Combo
- 0 تا 4 اقدام: ×1
- 5 تا 9: ×2
- 10 تا 14: ×3
- 15 تا 19: ×4
- 20 به بالا: ×5
- هر اقدام موفق پنجره Combo را یک ساعت تمدید می‌کند.
- حذف تسک یا پایان یک ساعت: Combo = 0.

## Rank
فقط تسک‌های R پیشرفت Rank می‌دهند.

## Focus
تا زمانی که تایمر 25 دقیقه‌ای فعال است، امتیاز همه تسک‌ها ×2 می‌شود.


## v2.20 rebase note
This release returns to the v2.19 feature baseline and only adds the compact Settings/audio changes documented in `UPDATE-20.md`.


## v2.21 HUD + Focus
- HUD labels: Done!, Rank, XP, Combo.
- Done! shows actions completed in the current game day.
- Focus timer uses English digits and icon-only start/stop controls.


## v2.22
Mission HUD cleanup on the v19 rebase: English combo timer/counter, compact multiplier display, and simplified mission metadata.


## v2.23
- Combo multipliers: 2 actions = ×2, 5 = ×3, 8 = ×4, 12 = ×5.
- Combo window is 30 minutes and extends after each completed task.
- Larger English combo timer with tiered animated flame.
- Android notification 2 minutes before combo expiry.


## v2.24
- Combo is now a campfire: x2 uses 2 logs, x3 uses 3, x4 uses 4, and x5 uses 5, with stronger flames by tier.
- Card swiping is faster and lighter with shorter transitions and no blur-heavy swap flash.
- Return-to-first-task button is redesigned as a compact neon arrow.
- Focus shows `Focus` while idle and switches to the English countdown only after start.


## v2.25 — Fire Timer + HUD Stats
- Combo timer no longer contains wood/log graphics; the full timer pill becomes an animated flame surface once combo ×2 is active.
- Flame intensity scales with combo tier (×2 to ×5).
- Tapping Done!, Rank, XP, or Combo opens a dedicated animated statistics panel for that metric.
- Existing v19-based game logic, 30-minute combo, focus, vaults, achievements, settings, and backup remain intact.


## v2.26 — TimeSheet Integrated
- TimeSheet v7 core workflow is integrated as a native page inside the gamification WebView.
- Navigation order: Game, Tasks, Vault, TimeSheet, Achievements, Settings.
- Weekly navigation supports ±10 weeks, Saturday-Friday rows, 07:00-24:00 slots, event creation/edit/delete/status, recurring weekly events, compact weekly overview, Jalali dates, and persistent storage.
- TimeSheet is visually rebuilt with the current gamification dark/light neon theme.
- TimeSheet data is stored inside the gamification state, so it participates in the existing export/import backup.


## v2.27 — TimeSheet Zoom + Reminder
- Added TimeSheet zoom in/out controls (70%–150%).
- Week header now shows only relative text: this week / N weeks before / N weeks after.
- Added icon-only return-to-current-week control when browsing another week.
- Removed TimeSheet week-overview option.
- Added optional 5-minute-before program notifications; reminders are OFF by default and activate only when checked per program.
- Recurring enabled reminders continue weekly; editing/deleting/status changes reschedule or cancel the alarm appropriately.

## v2.28 — Pinch Zoom + Light Contrast + HD Focus Audio
- TimeSheet subtitle "برنامه هفتگی" removed.
- TimeSheet zoom buttons removed; two-finger pinch zoom now controls the board from 50% to 150% and saves the zoom level.
- Settings heading changed to English `Settings` with the gear on the left.
- Light theme received a broad contrast/readability pass across HUD, mission card, task list, vault, achievements, settings, navigation, modals, and TimeSheet.
- Focus sound labels simplified: موج دریا، پیانو، جنگل، صدای آدم‌ها.
- All 10 focus ambience tracks regenerated as 48 kHz stereo 30-second loops at higher quality; piano is a newly synthesized Bach-inspired/public-domain Prelude in C major focus arrangement.


## v2.29 — Rewards Hub + Derakhtvare v21
- صندوق and دستاوردها are merged into one redesigned **پاداش‌ها** page with an internal two-tab switch.
- Bottom navigation stays at six items by replacing the separate achievements tab with a new **درختواره** tab.
- Added an integrated Derakhtvare v21 surface using the original v21 data model and tools, visually restyled to match Gamification.
- The Derakhtvare page includes four selectable modes: **PV / GPV**, **درختواره**, **مقایسه**, and **رنکینگ**.
- Tree add/edit member flows, PV/GPV entry, active-count data, circular hierarchy, tree zoom, person/time comparisons, ranking modes, and network-action data from v21 remain available.
- Dark/light theme is synchronized from Gamification into the embedded tree surface.
- Tree data is mirrored into the Gamification backup state so exported backups can carry the integrated tree data too.


## v2.30 — Clean Tree Hub + Pan/Zoom
- Removed the large Tree Hub title/version strip from Gamification.
- Removed the embedded page-title/header strip from the Tree app while keeping the four mode selectors.
- Expand-all and collapse-all are now icon-only controls.
- Tree view supports zoom in/out from 20% to 180%, two-finger pinch zoom, and one-finger free panning across both axes.
- Tree controls and pan surface are synchronized with Gamification dark/light themes.


## v2.31 — Card-first gameplay
- Removed the standalone Tasks page and its navigation item.
- Card title on the Game screen opens a per-card 30-day activity view.
- Card statistics show the last 30 days, current scheduled streak, and total completion count.
- A top-right three-dot menu on card statistics provides Edit Card, New Card, and permanent Delete Card.
- Card editor now contains only card name, short description, base points, and weekday recurrence.
- Game modes, labels, and default enabled/disabled status were removed.
- Rank cards are now automatic: any card with 30 or more base points contributes to Rank.
- Weekday recurrence controls which days a card appears in the Game deck.
- Return-to-first-card control was redesigned around the ⏪️ icon.


## v2.32 — PV / GPV Clean Layout
- Removed the per-person position counter from PV / GPV cards.
- Removed the swipe instruction under the cards.
- Simplified fields to `PV :`, `GPV :`, and `تعداد :` with the numeric value beside each label.
- Expanded the embedded PV / GPV workspace to use the full available height and eliminated unnecessary vertical page scrolling.

## v2.33 — Dream Board v20 Hub
- Removed the Rewards page and all Achievements / Vault / Chest UI and active reward-system hooks.
- Added a new main navigation page: `تابلورویا`.
- Added a self-contained Dream Board hub styled to match Gamification, following the same integration pattern as Derakhtvare.
- Dream Board hub sections: تابلو رویاها، اکسپلور، دارایی، آمار.
- Added year boards, dream items, completion tracking, values, categories, notes, photo upload, year/dream edit/delete, gallery filtering, asset tracking, one-million-dollar progress, and yearly statistics.
- Dream Board theme is synchronized with Gamification light/dark mode.
- Dream Board data is synchronized into the Gamification backup/import envelope.
- Android WebView image file chooser added for dream-photo selection.
