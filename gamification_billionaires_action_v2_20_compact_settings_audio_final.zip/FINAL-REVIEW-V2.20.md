# Final Review — v2.20.0

- Settings layout compacted for standard and short screens.
- Backup contains only Import / Export controls.
- Appearance contains only Day / Night.
- Day Start is a standalone card.
- Sound power icon is next to the Sound title; Test Effect is absent.
- 12 focus sound modes are present.
- Volume row is structurally separated from sound selection grid.
- v19 storage is discovered and normalized automatically on upgrade.
