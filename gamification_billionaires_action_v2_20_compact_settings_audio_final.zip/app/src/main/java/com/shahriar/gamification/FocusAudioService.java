package com.shahriar.gamification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class FocusAudioService extends Service {
    public static final String ACTION_START = "com.shahriar.gamification.FOCUS_START";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_VOLUME = "volume";
    public static final String EXTRA_END_AT = "endAt";
    private static final String CHANNEL = "focus_audio_v20";
    private static final int NOTIF_ID = 2520;

    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable finishRun;
    private String mode = "flow";
    private int volume = 45;
    private long endAt;

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        mode = safe(intent.getStringExtra(EXTRA_MODE));
        volume = Math.max(10, Math.min(100, intent.getIntExtra(EXTRA_VOLUME,45)));
        endAt = intent.getLongExtra(EXTRA_END_AT, System.currentTimeMillis()+1500000L);
        long remain = endAt-System.currentTimeMillis();
        if (remain<=0) { stopSelf(); return START_NOT_STICKY; }
        startForeground(NOTIF_ID, notification());
        playLoop(); schedule(remain);
        return START_REDELIVER_INTENT;
    }

    private String safe(String m){
        if(m==null) return "flow";
        switch(m){
            case "flow":case "pulse":case "rain":case "arcade":case "ocean_soft":case "ocean_deep":case "ocean_night":case "piano":case "forest":case "fire":case "cafe":case "meditation":return m;
            default:return "flow";
        }
    }
    private int track(){
        switch(mode){
            case "pulse":return R.raw.focus_pulse;
            case "rain":return R.raw.focus_rain;
            case "arcade":return R.raw.focus_arcade;
            case "ocean_soft":return R.raw.focus_ocean_soft;
            case "ocean_deep":return R.raw.focus_ocean_deep;
            case "ocean_night":return R.raw.focus_ocean_night;
            case "piano":return R.raw.focus_piano;
            case "forest":return R.raw.focus_forest;
            case "fire":return R.raw.focus_fire;
            case "cafe":return R.raw.focus_cafe;
            case "meditation":return R.raw.focus_meditation;
            default:return R.raw.focus_flow;
        }
    }
    private void playLoop(){
        release();
        try{
            player=MediaPlayer.create(this,track());
            if(player==null)return;
            try { player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK); } catch (Exception ignored) {}
            float v=0.05f+(volume/100f)*0.44f;
            player.setVolume(v,v);player.setLooping(true);player.start();
        }catch(Exception e){release();}
    }
    private void schedule(long ms){if(finishRun!=null)handler.removeCallbacks(finishRun);finishRun=()->{release();playEnd();};handler.postDelayed(finishRun,ms);}
    private void playEnd(){try{MediaPlayer m=MediaPlayer.create(this,R.raw.focus_complete);if(m==null){stopSelf();return;}m.setVolume(.58f,.58f);m.setOnCompletionListener(x->{try{x.release();}catch(Exception ignored){}stopForeground(true);stopSelf();});m.start();}catch(Exception e){stopSelf();}}
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,20,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_focus_notification).setContentTitle("تمرکز ۲۵ دقیقه‌ای فعال است").setContentText("صدای تمرکز در پس‌زمینه ادامه دارد").setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).setCategory(NotificationCompat.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW).build();
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){NotificationManager n=getSystemService(NotificationManager.class);if(n!=null){NotificationChannel c=new NotificationChannel(CHANNEL,"تمرکز",NotificationManager.IMPORTANCE_LOW);c.setSound(null,null);n.createNotificationChannel(c);}}}
    private void release(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    @Override public void onDestroy(){if(finishRun!=null)handler.removeCallbacks(finishRun);release();super.onDestroy();}
    @Nullable @Override public IBinder onBind(Intent intent){return null;}
}
