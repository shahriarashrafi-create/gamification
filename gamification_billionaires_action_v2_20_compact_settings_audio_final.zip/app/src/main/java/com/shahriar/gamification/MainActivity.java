package com.shahriar.gamification;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 4201;
    private static final int REQ_IMPORT = 4202;
    private static final long DOUBLE_BACK_MS = 1800L;

    private WebView webView;
    private FrameLayout root;
    private String pendingBackup;
    private long lastBack = 0L;
    private boolean backBusy = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        applySystemBars(false);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5, 14, 24));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 14, 24));
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void applySystemBars(boolean light) {
        WindowInsetsControllerCompat c = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(light);
        c.setAppearanceLightNavigationBars(light);
        if (root != null) root.setBackgroundColor(light ? Color.rgb(238, 245, 251) : Color.rgb(5, 14, 24));
        if (webView != null) webView.setBackgroundColor(light ? Color.rgb(238, 245, 251) : Color.rgb(5, 14, 24));
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void setLightMode(boolean light) {
            runOnUiThread(() -> applySystemBars(light));
        }

        @JavascriptInterface
        public void exportBackup(String json) {
            if (json == null || json.trim().isEmpty()) return;
            runOnUiThread(() -> {
                pendingBackup = json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
                i.putExtra(Intent.EXTRA_TITLE, "Billionaires_Action_Backup_" + stamp + ".json");
                startActivityForResult(i, REQ_EXPORT);
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                startActivityForResult(i, REQ_IMPORT);
            });
        }

        @JavascriptInterface
        public void startFocusAudio(String mode, int volume, long endAt) {
            runOnUiThread(() -> {
                Intent i = new Intent(MainActivity.this, FocusAudioService.class);
                i.setAction(FocusAudioService.ACTION_START);
                i.putExtra(FocusAudioService.EXTRA_MODE, mode == null ? "flow" : mode);
                i.putExtra(FocusAudioService.EXTRA_VOLUME, Math.max(10, Math.min(100, volume)));
                i.putExtra(FocusAudioService.EXTRA_END_AT, endAt);
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i); else startService(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void stopFocusAudio() {
            runOnUiThread(() -> {
                try { stopService(new Intent(MainActivity.this, FocusAudioService.class)); } catch (Exception ignored) {}
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackup != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (out != null) {
                        out.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        ok = true;
                    }
                } catch (Exception ignored) {}
            }
            pendingBackup = null;
            final boolean result = ok;
            if (webView != null) webView.post(() -> webView.evaluateJavascript("backupExportFinished(" + result + ")", null));
            return;
        }
        if (requestCode == REQ_IMPORT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try (InputStream in = getContentResolver().openInputStream(uri);
                     BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line).append('\n');
                    String raw = sb.toString();
                    if (webView != null) webView.post(() -> webView.evaluateJavascript("receiveBackupFromAndroid(" + JSONObject.quote(raw) + ")", null));
                } catch (Exception e) {
                    Toast.makeText(this, "فایل بکاپ خوانده نشد", Toast.LENGTH_SHORT).show();
                }
            } else if (webView != null) {
                webView.post(() -> webView.evaluateJavascript("backupImportCancelled()", null));
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.post(() -> webView.evaluateJavascript("resumeFromBackground()", null));
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.evaluateJavascript("prepareForBackground()", null);
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView == null || backBusy) return;
        backBusy = true;
        webView.evaluateJavascript("(document.querySelector('.page.active')||{}).id||'home'", value -> {
            backBusy = false;
            String page = value == null ? "home" : value.replace("\"", "").trim();
            if (!"home".equals(page)) {
                lastBack = 0L;
                webView.evaluateJavascript("goPage('home')", null);
                return;
            }
            long now = SystemClock.elapsedRealtime();
            if (now - lastBack <= DOUBLE_BACK_MS) {
                lastBack = 0L;
                webView.evaluateJavascript("prepareForBackground()", null);
                moveTaskToBack(true);
            } else {
                lastBack = now;
                Toast.makeText(this, "برای خروج دوباره دکمه برگشت را بزن", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
