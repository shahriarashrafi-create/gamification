# Update 20 — Compact Settings + Focus Sound Library

- ارتفاع Backup کمتر و فقط Import / Export باقی مانده است.
- ارتفاع Appearance کمتر و فقط روز / شب نمایش داده می‌شود.
- Start Day از Appearance جدا شده و کارت مستقل دارد.
- Sound Card کوتاه‌تر شده، Test Effect حذف شده و Power Icon کنار عنوان اصلی قرار گرفته است.
- متن نسخه و متن‌های توضیحی اضافی تنظیمات حذف شده‌اند.
- عنوان «صدای ۲۵ دقیقه‌ای» حذف شده است.
- Volume در ردیف مستقل است تا با انتخاب Sound Mode تداخل نداشته باشد.
- Sound Modeهای جدید: موج آرام، موج عمیق، ساحل شب، پیانو، جنگل، آتش، کافه و مدیتیشن.
- Sound Modeهای قبلی Flow / Pulse / Rain / Arcade حفظ شده‌اند.
- پیشرفت نسخه ۱۹ از LocalStorage قدیمی به صورت خودکار مهاجرت می‌کند.
