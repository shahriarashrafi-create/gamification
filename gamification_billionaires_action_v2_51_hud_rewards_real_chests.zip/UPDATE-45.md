# Update 45 — v2.45.0

- Ranking: removed the explanatory ranking subtitle.
- Dreamboard: completed dreams are always placed after active dreams inside the same year.
- Dreamboard: the three-dot menu now exposes priority controls with up/down arrows; editing remains available from the same menu.
- Explore: added direct dream/photo creation without choosing a year.
- Explore: combines board dreams and Explore-only items, randomizes the feed on render, and presents one full-screen image per vertical snap page.
- Explore: bottom overlay shows title on the right and price on the left.
- Explore-only entries are included in the Dreamboard state, so they are covered by the existing app export/import backup flow.
