# Update 43 — v2.43.0

- Added a three-dot control beside each person name in PV/GPV.
- Added editable person name, PV goal, GPV goal, and active-count goal.
- Added a per-person To Do List below Direct Add; completed items move to the bottom and items can be deleted.
- To Do items and new goal fields are included in tree state, daily snapshots, Export/Import, and app backup.
- Circular tree no longer shows add or three-dot controls on circles.
- Replaced the collapsed-branch plus marker with a chevron so circles contain no add-plus control.
- Made root and member circles the same size and enlarged PV/GPV/count numbers.
