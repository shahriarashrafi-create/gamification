# Update 44 — Comparison redesign

- Compact comparison mode tabs.
- Temporal comparison is the default each time Comparison opens.
- Removed instructional subtitles.
- Person + three dates are shown on one line.
- Added archive-aware Persian date picker with separate year/month/day selectors.
- Both comparison modes now show only PV, GPV, and active people.
- Removed extra comparison metrics and redundant labels.
