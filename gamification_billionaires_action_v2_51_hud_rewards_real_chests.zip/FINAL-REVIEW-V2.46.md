# Final Review V2.46

- Tree names prioritized; metrics slightly smaller.
- Comparison values enlarged.
- To Do unfinished badge added.
- Dream/Explore photos optimized on import to reduce storage pressure.
- Settings day-start label and collapsible Pomodoro sound controls.
- Assets total now includes achieved dreams plus manually added assets.
- Million-dollar progress block removed; next 3 priority goals shown.
- Dreamboard Stats tab removed.
