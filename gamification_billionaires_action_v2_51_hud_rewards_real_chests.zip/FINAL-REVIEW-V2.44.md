# Final Review — v2.44.0

Comparison screen was simplified around the requested three metrics: PV, GPV, and active people. Temporal comparison is the default, date selection uses a dedicated year/month/day picker tied to available daily archive records, and the person plus three dates fit on a single compact row.
