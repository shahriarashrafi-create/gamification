/* v2.51 Game HUD, progression summaries and claimable reward chests. */
const TOTAL_CHEST_LADDER_V51=[
  {score:5000,xp:300,title:'شروع قدرتمند'},{score:12000,xp:480,title:'سازنده عادت'},{score:22000,xp:700,title:'شکارچی پیشرفت'},
  {score:35000,xp:950,title:'ماشین اقدام'},{score:52000,xp:1250,title:'فرمانده عملکرد'},{score:75000,xp:1600,title:'استاد استمرار'},
  {score:105000,xp:2050,title:'معمار موفقیت'},{score:145000,xp:2600,title:'سطح نخبگان'},{score:200000,xp:3300,title:'بازیگر افسانه‌ای'},
  {score:275000,xp:4200,title:'میلیاردرِ اقدام'}
];
const TODAY_TITLES_V51=['رکوردشکن','روز طلایی','بی‌توقف','آتشین','شکارچی رکورد','فوق‌العاده','سلطان روز','افسانه امروز'];
const RANK_MILESTONES_V51=[3,5,8,12,16,20,25,30,35,40,45,50];
let activeHudKindV51='today',pendingChestV51=null,chestOpenedV51=false;

function ensureRewardHubStateV51(){
  if(!state.rewards||typeof state.rewards!=='object')state.rewards={};
  let r=state.rewards;
  if(!r.claims||typeof r.claims!=='object')r.claims={};
  r.claims.todayDate=typeof r.claims.todayDate==='string'?r.claims.todayDate:'';
  r.claims.totalIndex=Math.max(0,Number(r.claims.totalIndex||0));
  r.claims.comboBest=Math.max(0,Number(r.claims.comboBest||0));
  r.claims.rankIndex=Math.max(0,Number(r.claims.rankIndex||0));
  r.todayWins=Math.max(0,Number(r.todayWins||0));
  r.todayWinStreak=Math.max(0,Number(r.todayWinStreak||0));
  r.lastTodayWinDate=typeof r.lastTodayWinDate==='string'?r.lastTodayWinDate:'';
  if(!Array.isArray(r.titles))r.titles=[];
  r.titles=[...new Set(r.titles.filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim()))];
  r.activeTitle=(typeof r.activeTitle==='string'&&r.activeTitle.trim())?r.activeTitle.trim():(r.titles.length?r.titles[r.titles.length-1]:'شروع مسیر');
  return r;
}
function prevDateKeyV51(k){let d=dateFromKey(k);d.setDate(d.getDate()-1);return dateKeyFromDate(d)}
function scoreForDateV51(k){if(k===state.date)return Number(state.dayScore||0);let row=(state.history||[]).find(x=>x&&x.date===k);return Math.max(0,Number(row&&row.score||0))}
function bestDailyScoreV51(){let vals=(state.history||[]).filter(Boolean).map(x=>Number(x.score||0));vals.push(Number(state.dayScore||0));return Math.max(0,...vals)}
function rewardRarityV51(level){let n=Math.max(1,Number(level||1));return n>=8?'mythic':n>=6?'legendary':n>=4?'epic':n>=2?'gold':'silver'}
function rarityLabelV51(r){return({silver:'نقره‌ای',gold:'طلایی',epic:'حماسی',legendary:'افسانه‌ای',mythic:'اسطوره‌ای'})[r]||'ویژه'}
function titleAtV51(arr,index,prefix){index=Math.max(0,Number(index||0));return index<arr.length?arr[index]:`${prefix} ${fa(index+1)}`}
function nextGeneratedTotalV51(index){let last=TOTAL_CHEST_LADDER_V51[TOTAL_CHEST_LADDER_V51.length-1],extra=index-(TOTAL_CHEST_LADDER_V51.length-1),score=last.score+Math.max(1,extra)*35000;return{score,xp:last.xp+Math.max(1,extra)*650,title:'اسطوره امتیاز '+fa(index+1)}}
function totalStepV51(index){return TOTAL_CHEST_LADDER_V51[index]||nextGeneratedTotalV51(index)}
function generatedRankMilestoneV51(index){if(index<RANK_MILESTONES_V51.length)return RANK_MILESTONES_V51[index];return 50+(index-RANK_MILESTONES_V51.length+1)*5}
function rankVisualV51(rank){let n=Math.max(1,Number(rank||1)),tier=n>=30?6:n>=20?5:n>=12?4:n>=8?3:n>=5?2:n>=3?1:0;let names=['Bronze','Silver','Gold','Platinum','Diamond','Master','Mythic'];let faNames=['برنز','نقره‌ای','طلایی','پلاتینیوم','الماس','مستر','اسطوره'];let marks=['◇','◈','✦','✧','◆','♛','✺'];return{tier,name:names[tier],faName:faNames[tier],mark:marks[tier]}}
function todayRewardStatusV51(){
  let r=ensureRewardHubStateV51(),prev=prevDateKeyV51(state.date),y=scoreForDateV51(prev),target=y>0?y:250,claimed=r.claims.todayDate===state.date,unlocked=!claimed&&Number(state.dayScore||0)>target;
  let winIndex=Math.max(0,r.todayWins),rarity=rewardRarityV51(winIndex+1),title=titleAtV51(TODAY_TITLES_V51,winIndex,'رکوردشکن');
  let xp=120+winIndex*90;
  return{kind:'today',unlocked,claimed,target,current:Number(state.dayScore||0),xp,title,rarity,kicker:'TODAY RECORD',chestTitle:claimed?'صندوق امروز دریافت شد':unlocked?'رکورد دیروز شکسته شد!':'صندوق رکورد امروز',text:claimed?'فردا بیشتر از امتیاز امروز بزن تا صندوق قوی‌تر باز شود.':unlocked?`صندوق ${rarityLabelV51(rarity)} آماده است • پاداش رکورد ×۲`:`بیشتر از ${fa(target)} امتیاز بزن؛ رکورد دیروز ${fa(y)} بوده است.`,extra:`بردهای رکوردی: ${fa(r.todayWins)} • استریک رکورد: ${fa(r.todayWinStreak)}`}
}
function totalRewardStatusV51(){
  let r=ensureRewardHubStateV51(),idx=r.claims.totalIndex,step=totalStepV51(idx),prev=idx?totalStepV51(idx-1).score:0,current=Number(state.totals&&state.totals.score||0),unlocked=current>=step.score,rarity=rewardRarityV51(idx+1);
  return{kind:'total',unlocked,claimed:false,target:step.score,previous:prev,current,xp:step.xp,title:step.title,rarity,kicker:'TOTAL MILESTONE',chestTitle:unlocked?`صندوق مرحله ${fa(idx+1)} آماده است`:`صندوق Total • مرحله ${fa(idx+1)}`,text:unlocked?`از مرز ${fa(step.score)} امتیاز عبور کردی.`:`${fa(Math.max(0,step.score-current))} امتیاز تا صندوق ${rarityLabelV51(rarity)} بعدی`,extra:`پله ${fa(idx+1)} • عنوان: ${step.title}`}
}
function comboRewardStatusV51(){
  let r=ensureRewardHubStateV51(),best=Math.max(0,Number(state.bestCombo||0)),claimed=r.claims.comboBest,unlocked=best>claimed&&best>=2,target=unlocked?best:Math.max(2,best+1),level=Math.max(1,best),rarity=rewardRarityV51(Math.floor(best/3)+1),xp=70+best*28;
  let baseTitle=best>=30?'کمبوی جاودان':best>=20?'هیولای کمبو':best>=12?'آتش بی‌پایان':best>=8?'زنجیره طلایی':best>=5?'شکارچی کمبو':best>=2?'جرقه کمبو':'شروع کمبو',title=baseTitle+' '+fa(Math.max(1,best));
  return{kind:'combo',unlocked,claimed:false,target,current:best,xp,title,rarity,kicker:'COMBO RECORD',chestTitle:unlocked?`رکورد Combo ${fa(best)}!`:'صندوق رکورد بعدی',text:unlocked?`از رکورد ثبت‌شده ${fa(claimed)} عبور کردی؛ صندوق قوی‌تر آماده است.`:`به Combo ${fa(target)} برس تا رکورد جدید و صندوق تازه ثبت شود.`,extra:`بهترین Combo: ${fa(best)} • رکورد دریافت‌شده: ${fa(claimed)}`}
}
function rankRewardStatusV51(){
  let r=ensureRewardHubStateV51(),idx=r.claims.rankIndex,target=generatedRankMilestoneV51(idx),unlocked=Number(state.rank||1)>=target,rarity=rewardRarityV51(idx+2),xp=260+idx*180;
  let baseTitle=target>=40?'فرمانروای رنک':target>=25?'مستر رنک':target>=16?'الماس رقابت':target>=8?'شکارچی رنک':target>=5?'طلایی صعود':'صعودگر',title=baseTitle+' '+fa(target);
  return{kind:'rank',unlocked,claimed:false,target,current:Number(state.rank||1),xp,title,rarity,kicker:'RANK CHEST',chestTitle:unlocked?`صندوق ویژه Rank ${fa(target)}`:`صندوق ویژه در Rank ${fa(target)}`,text:unlocked?'این صندوق فقط هر چند رنک یک‌بار ظاهر می‌شود؛ آماده دریافت است.':`${fa(Math.max(0,target-state.rank))} رنک تا صندوق ${rarityLabelV51(rarity)} بعدی`,extra:`صندوق ویژه شماره ${fa(idx+1)} • عنوان: ${title}`}
}
function rewardStatusForKindV51(kind){return kind==='total'?totalRewardStatusV51():kind==='combo'?comboRewardStatusV51():kind==='rank'?rankRewardStatusV51():todayRewardStatusV51()}
function rewardProgressV51(s){if(s.kind==='total'){let span=Math.max(1,s.target-(s.previous||0));return Math.max(0,Math.min(100,(s.current-(s.previous||0))/span*100))}if(s.kind==='rank')return Math.max(0,Math.min(100,s.current/s.target*100));return Math.max(0,Math.min(100,s.current/Math.max(1,s.target)*100))}
function chestDotV51(id,status){let el=document.getElementById(id);if(!el)return;el.classList.toggle('ready',!!status.unlocked);el.title=status.unlocked?'صندوق آماده دریافت است':''}
function renderGameHudV51(){
  let r=ensureRewardHubStateV51();
  let level=document.getElementById('levelHudV51');if(level)level.textContent='Lv '+String(state.level||1);
  let title=document.getElementById('activeTitleHudV51');if(title)title.textContent=r.activeTitle||'شروع مسیر';
  let today=document.getElementById('todayHudV51');if(today)today.textContent=fa(state.dayScore||0);
  let total=document.getElementById('totalHudV51');if(total)total.textContent=fa(state.totals&&state.totals.score||0);
  let combo=document.getElementById('comboHudV51');if(combo)combo.textContent=fa(state.combo||0);
  let csub=document.getElementById('comboSubV51');if(csub)csub.textContent='رکورد '+fa(state.bestCombo||0);
  let rank=document.getElementById('rankHudV51');if(rank)rank.textContent=fa(state.rank||1);
  let rsub=document.getElementById('rankSubV51');if(rsub)rsub.textContent='بعدی '+fa(Number(state.rank||1)+1);
  chestDotV51('todayChestDotV51',todayRewardStatusV51());chestDotV51('totalChestDotV51',totalRewardStatusV51());chestDotV51('comboChestDotV51',comboRewardStatusV51());chestDotV51('rankChestDotV51',rankRewardStatusV51());
}
function renderHome(){
  ensureRewardHubStateV51();let missionEl=document.getElementById('mission');missionEl.removeAttribute('style');missionEl.className='card mission card-mode-free';missionEl.innerHTML=missionHtml();
  let ds=document.getElementById('dayScore');if(ds)ds.textContent=`امتیاز امروز: ${fa(state.dayScore)}`;let dl=document.getElementById('dateLabel');if(dl)dl.textContent=todayFa();
  renderGameHudV51();updateComboHudDom();bindMissionSwipe();updateFocusTimerDom();
}
function updateComboHudDom(){
  syncComboExpiry();let n=Math.max(0,Number(state.combo||0)),num=document.getElementById('comboHudV51'),sub=document.getElementById('comboSubV51'),chip=document.getElementById('deckComboChip');
  if(num)num.textContent=fa(n);if(sub)sub.textContent='رکورد '+fa(state.bestCombo||0);
  if(chip){chip.classList.toggle('hidden',n<=0);chip.innerHTML=n>0?comboFlameHtml(n)+`<span class="combo-time">${comboClock()}</span>`:'';chip.dataset.tier=String(comboTier(n))}
  chestDotV51('comboChestDotV51',comboRewardStatusV51());
}
function updateFocusTimerDom(){
  let active=focusIsActive(),timer=document.getElementById('focusTimerText'),bar=document.getElementById('focusTimerBar'),strip=document.getElementById('focusStrip'),ring=document.getElementById('focusTimerRing'),status=document.getElementById('focusStatusV51'),start=document.getElementById('focusStartButton'),stop=document.getElementById('focusStopButton');
  let elapsed=active?focusProgressPct():0,remain=active?Math.max(0,100-elapsed):100;
  if(timer)timer.textContent=active?focusTimeText():'25:00';if(bar)bar.style.width=remain+'%';if(ring)ring.style.setProperty('--focusRemain',remain+'%');if(strip)strip.classList.toggle('active',active);if(status)status.textContent=active?'تا پایان Focus ادامه بده؛ پاداش کارت‌ها ×۲ است.':'برای شروع آماده‌ای؟';
  if(start){start.disabled=active;start.classList.toggle('muted-btn',active)}if(stop){stop.disabled=!active;stop.classList.toggle('muted-btn',!active)}
}
function hudMetricV51(label,value,sub=''){return `<div class="hud-detail-metric"><small>${label}</small><strong>${value}</strong>${sub?`<em>${sub}</em>`:''}</div>`}
function rankStageHtmlV51(){let a=rankVisualV51(state.rank),b=rankVisualV51(Number(state.rank)+1);return `<div class="rank-orbit-v51"><i></i><i></i><span class="rank-current-v51">${a.mark}<small>${a.faName}</small><b>${fa(state.rank)}</b></span><span class="rank-next-v51">${b.mark}<small>بعدی • ${b.faName}</small><b>${fa(Number(state.rank)+1)}</b></span></div>`}
function openHudDetail(kind){
  ensureDate();syncComboExpiry();ensureRewardHubStateV51();activeHudKindV51=['today','total','combo','rank'].includes(kind)?kind:'today';let status=rewardStatusForKindV51(activeHudKindV51),week=periodTotals(7),month=periodTotals(30),y=scoreForDateV51(prevDateKeyV51(state.date)),best=bestDailyScoreV51(),r=state.rewards;
  let cfg={title:'Today',icon:'✦',kicker:'DAILY SCORE',caption:'رکورد امروز را بشکن و صندوق روزانه قوی‌تری بگیر.',value:fa(state.dayScore||0),sub:'امتیاز امروز',bar:rewardProgressV51(status),cls:'detail-today',grid:[hudMetricV51('دیروز',fa(y)),hudMetricV51('رکورد',fa(best)),hudMetricV51('۷ روز',fa(week.score)),hudMetricV51('رکوردهای برده',fa(r.todayWins||0))]};
  if(activeHudKindV51==='total')cfg={title:'Total',icon:'★',kicker:'ALL TIME SCORE',caption:'صندوق‌های Total با فاصله چند روز بازی طراحی شده‌اند و پله‌پله کمیاب‌تر می‌شوند.',value:fa(state.totals&&state.totals.score||0),sub:'مجموع امتیازها',bar:rewardProgressV51(status),cls:'detail-total',grid:[hudMetricV51('۷ روز',fa(week.score)),hudMetricV51('۳۰ روز',fa(month.score)),hudMetricV51('کارت انجام‌شده',fa(state.totals&&state.totals.done||0)),hudMetricV51('صندوق‌های گرفته‌شده',fa(r.claims.totalIndex||0))]};
  else if(activeHudKindV51==='combo')cfg={title:'Combo',icon:'🔥',kicker:'COMBO RECORD',caption:'هر بار رکورد قبلی Combo را رد کنی، صندوق بعدی ارزش بیشتری دارد.',value:fa(state.combo||0),sub:state.combo?`×${fa(comboMultiplier(state.combo))} • ${comboClock()}`:'کمبوی فعلی',bar:rewardProgressV51(status),cls:'detail-combo',grid:[hudMetricV51('بهترین',fa(state.bestCombo||0)),hudMetricV51('ضریب',`×${fa(comboMultiplier(state.combo))}`),hudMetricV51('زمان',state.combo?comboClock():'00:00'),hudMetricV51('رکورد دریافت‌شده',fa(r.claims.comboBest||0))]};
  else if(activeHudKindV51==='rank'){let need=rankNeed(state.rank),rv=rankVisualV51(state.rank);cfg={title:'Rank',icon:rv.mark,kicker:'RANK ASCENSION',caption:'رنک بعدی را از قبل ببین؛ صندوق‌های Rank فقط در نقاط ویژه مسیر باز می‌شوند.',value:fa(state.rank),sub:`${fa(state.rankProgress)} / ${fa(need)} تا رنک بعدی`,bar:Math.min(100,state.rankProgress/Math.max(1,need)*100),cls:'detail-rank',grid:[hudMetricV51('سطح',rv.faName),hudMetricV51('R کل',fa(state.totals&&state.totals.rank||0)),hudMetricV51('بعدی',fa(Number(state.rank)+1)),hudMetricV51('صندوق Rank',fa(r.claims.rankIndex||0))]};}
  let modal=document.getElementById('hudDetailModal'),card=document.getElementById('hudDetailCard');if(!modal||!card)return;
  document.getElementById('hudDetailIcon').textContent=cfg.icon;document.getElementById('hudDetailKicker').textContent=cfg.kicker;document.getElementById('hudDetailTitle').textContent=cfg.title;document.getElementById('hudDetailCaption').textContent=cfg.caption;document.getElementById('hudDetailValue').textContent=cfg.value;document.getElementById('hudDetailSub').textContent=cfg.sub;document.getElementById('hudDetailBar').style.width=Math.max(0,Math.min(100,cfg.bar||0))+'%';document.getElementById('hudDetailGrid').innerHTML=cfg.grid.join('');
  let rs=document.getElementById('hudRankStageV51');if(rs){rs.hidden=activeHudKindV51!=='rank';rs.innerHTML=activeHudKindV51==='rank'?rankStageHtmlV51():''}
  card.classList.remove('detail-today','detail-total','detail-combo','detail-rank','chest-ready');card.classList.add(cfg.cls);card.classList.toggle('chest-ready',!!status.unlocked);renderNextChestV51(status);gameSound(activeHudKindV51==='rank'?'rank':'tap');haptic(10);modal.classList.add('show');
}
function renderNextChestV51(status){let box=document.getElementById('hudNextChestV51');if(!box)return;box.className='next-chest-card-v51 rarity-'+status.rarity+(status.unlocked?' unlocked':' locked');document.getElementById('hudChestKickerV51').textContent=status.unlocked?'صندوق آماده دریافت':'صندوق بعدی';document.getElementById('hudChestTitleV51').textContent=status.chestTitle;document.getElementById('hudChestTextV51').textContent=status.text+' • +'+fa(status.xp)+' XP • عنوان: '+status.title;document.getElementById('hudChestActionV51').textContent=status.unlocked?'باز کردن':'پیشرفت';document.getElementById('hudChestIconV51').className='mini-chest-v51 rarity-'+status.rarity}
function closeHudDetail(){let m=document.getElementById('hudDetailModal');if(m)m.classList.remove('show')}
function openChestForHud(){let s=rewardStatusForKindV51(activeHudKindV51);if(!s.unlocked){gameSound('tap');toast(s.text);return}pendingChestV51=s;chestOpenedV51=false;let modal=document.getElementById('chestModalV51'),card=document.getElementById('chestStageCardV51'),chest=document.getElementById('bigChestV51');card.className='chest-stage-card-v51 rarity-'+s.rarity;chest.className='big-chest-v51 rarity-'+s.rarity;document.getElementById('chestKickerV51').textContent=s.kicker;document.getElementById('chestTitleV51').textContent=s.chestTitle;document.getElementById('chestHintV51').textContent='برای باز کردن صندوق لمس کن';document.getElementById('chestRewardCopyV51').hidden=true;document.getElementById('claimChestV51').hidden=true;modal.classList.add('show');gameSound('achievement');haptic([14,30,12])}
function closeChestV51(){let m=document.getElementById('chestModalV51');if(m)m.classList.remove('show');pendingChestV51=null;chestOpenedV51=false}
function advanceChestOpeningV51(ev){ev&&ev.stopPropagation&&ev.stopPropagation();if(!pendingChestV51||chestOpenedV51)return;chestOpenedV51=true;let chest=document.getElementById('bigChestV51');chest.classList.add('opened');document.getElementById('chestHintV51').textContent='جایزه داخل صندوق آماده دریافت است';document.getElementById('chestRewardXpV51').textContent='+'+fa(pendingChestV51.xp)+' XP';document.getElementById('chestRewardTitleV51').textContent='عنوان جدید: '+pendingChestV51.title;document.getElementById('chestRewardExtraV51').textContent=pendingChestV51.extra||rarityLabelV51(pendingChestV51.rarity);document.getElementById('chestRewardCopyV51').hidden=false;document.getElementById('claimChestV51').hidden=false;gameSound(pendingChestV51.kind==='rank'?'rank':'level');haptic([30,40,22,60]);makeConfetti(pendingChestV51.rarity==='mythic'?100:pendingChestV51.rarity==='legendary'?80:55)}
function claimChestRewardV51(){
  if(!pendingChestV51||!chestOpenedV51)return;let freshStatus=rewardStatusForKindV51(pendingChestV51.kind);if(!freshStatus.unlocked){closeChestV51();return}let r=ensureRewardHubStateV51(),s=freshStatus;
  if(s.kind==='today'){let prev=prevDateKeyV51(state.date);r.todayWinStreak=r.lastTodayWinDate===prev?Number(r.todayWinStreak||0)+1:1;r.lastTodayWinDate=state.date;r.todayWins=Number(r.todayWins||0)+1;r.claims.todayDate=state.date}
  else if(s.kind==='total')r.claims.totalIndex=Number(r.claims.totalIndex||0)+1;
  else if(s.kind==='combo')r.claims.comboBest=Math.max(Number(r.claims.comboBest||0),Number(state.bestCombo||0));
  else if(s.kind==='rank')r.claims.rankIndex=Number(r.claims.rankIndex||0)+1;
  if(!r.titles.includes(s.title))r.titles.push(s.title);r.activeTitle=s.title;let lv=processLevel(s.xp);state.log.unshift(`🎁 صندوق ${s.kind.toUpperCase()} • +${s.xp} XP • عنوان ${s.title}`);save();render();gameSound(lv?'level':'achievement');haptic([35,25,60]);makeConfetti(s.rarity==='mythic'?120:90);closeChestV51();openHudDetail(s.kind);toast('جایزه ثبت شد • '+s.title+(lv?' • Lv '+fa(state.level):''));
}
ensureRewardHubStateV51();
