# FINAL REVIEW — V2.50

Version: 2.50.0 (versionCode 250)

## Main changes
1. Dedicated Pomodoro sound picker page.
2. Gallery-reference Dreamboard media using persistable Android content URIs.
3. No image duplication for newly selected Android gallery images.
4. Non-destructive crop metadata.
5. Backup remains lightweight for new gallery images while retaining legacy IndexedDB archive compatibility.

## Compatibility
- Existing idb: media references remain supported.
- Existing data:image legacy references can still migrate to IndexedDB.
- Gallery URI backups are reliable on the same device/install while persisted permissions remain valid; moving the JSON alone to another device may require re-linking the image from that device's gallery.
