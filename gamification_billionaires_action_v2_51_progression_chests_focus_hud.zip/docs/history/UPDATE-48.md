# Update 48 — architecture cleanup

- Dreamboard legacy CSS and obsolete year-detail shell removed.
- Main index CSS and JavaScript split into dedicated assets: game core, bridge, settings/backup, timesheet, shell.
- Tree daily history now has one canonical runtime/storage representation (`archive` / `treeDailyHistory`). Old `dailyHistory`, `dailySnapshots`, and `treeDailySnapshots` are read only for migration/import compatibility.
- Parent app no longer persists Tree/List/Dream snapshots inside the core game state. Module state remains owned by each iframe; the parent keeps only transient bridge caches for backup/import handoff.
- Historical UPDATE/FINAL-REVIEW files moved to `docs/history`.
- App version bumped to 2.48.0 / versionCode 248.
