# Final Review — v2.49

Settings redesigned and wired to real app behavior. Existing backups remain compatible. Image cleanup preserves all currently referenced Dreamboard/Explore images. The new animation preference defaults to enabled for existing users.
