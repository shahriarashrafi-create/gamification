# Update 49

- Rebuilt Settings into four compact cards: Game, Focus, Display, Data.
- Game: compact day-start row.
- Focus: sound master toggle, collapsible sound picker and volume.
- Display: day/night segmented control and real animation toggle.
- Data: Export, Import, live image storage usage, orphan media cleanup, app version.
- Image management reads the Dreamboard IndexedDB store and cleans only unreferenced image blobs.
- Animation preference propagates to Tree, List and Dreamboard.
- Version bumped to 2.49.0 / versionCode 249.
