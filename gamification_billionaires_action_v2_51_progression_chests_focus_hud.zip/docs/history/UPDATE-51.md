# UPDATE 51 — Progression HUD, Chests, Focus Hero

- Replaced the previous four-card HUD with crown/level + Today / Total / Combo / Rank.
- Added dedicated summary views and claimable reward chests.
- Today reward: beat yesterday score; reward tier grows across record wins.
- Total reward: milestone ladder begins at 5,000 points and scales upward.
- Combo reward: each new all-time combo record can unlock a stronger chest.
- Rank reward: special chests at selected rank milestones, with animated next-rank preview.
- Chest flow: summary -> cinematic closed chest -> tap to open -> explicit Claim.
- Claims grant XP and a persistent title; reward state is included in normal backup state.
- Focus redesigned with circular green remaining-time ring and motivational success background.
- Current mission card made vertically lighter while preserving swipe / done / delete / card stats behavior.
