# FINAL REVIEW — v2.51

Version: 2.51.0 (versionCode 251)

## Game HUD
- Left crown displays current level as `Lv N`.
- Today = current game-day score.
- Total = all-time task score.
- Combo = live combo; sublabel shows best combo.
- Rank = current rank and next-rank hint.
- Reward-ready dots appear on metrics with a claimable chest.

## Reward system
- Reward state persists under `state.rewards`.
- Chest claims cannot be collected twice because each track stores its own claim cursor/date/record.
- Claiming grants XP and stores a title; the latest title is shown under the crown.
- Full backup automatically includes this state.

## Focus
- 25-minute timer uses a circular ring whose green arc is remaining time.
- Idle timer displays 25:00; start/stop behavior and ×2 scoring remain unchanged.

## Compatibility
- Existing v2.50 player state is normalized without wiping progress.
- Existing cards, history, Combo, Rank, Tree, Dreamboard, List and TimeSheet data remain unchanged.
