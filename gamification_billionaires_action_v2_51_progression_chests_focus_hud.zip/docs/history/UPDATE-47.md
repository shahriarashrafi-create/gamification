# Update 47 — IndexedDB Dream Media + Cleanup

Version 2.47.0 cumulative update.

## Dream / Explore image storage
- Dream and Explore photos are no longer persisted as Base64 inside LocalStorage/state.
- Added `dream_media_v47.js` with IndexedDB-backed Blob storage.
- State now stores only lightweight `idb:<key>` references.
- Existing Base64 images are migrated automatically on first load.
- Replaced FileReader-based image preprocessing with temporary object URLs to reduce peak memory overhead.
- Explore/board image hydration is lazy via IntersectionObserver so off-screen images are not all loaded at once.
- Unreferenced media is pruned after image replacement/deletion/year deletion.

## Backup / restore compatibility
- Backup schema bumped to 4.
- Full export temporarily embeds referenced IndexedDB images in `imageArchive` inside the backup JSON.
- Restore writes archived images back to IndexedDB before applying Dreamboard state.
- Parent app state remains compact and never retains `imageArchive` or legacy Base64 images.
- Old backups containing Base64 Dream/Explore images are accepted and migrated.

## Cleanup / fixes
- Android versionCode/versionName bumped to 247 / 2.47.0.
- In-app `APP_VERSION` fixed from stale 2.44.0 to 2.47.0.
- Removed the hidden Stats view, Stats renderer, million-dollar progress logic/styles, and dead Dreamboard helper functions.
- Dreamboard switcher corrected from a four-column grid to three columns.
- Removed several unreachable helpers from the main game, Tree, List, and stale Java imports/Back fields.
