# UPDATE 50

- Focus sound selector moved to a dedicated settings page.
- Dreamboard and Explore image picking now uses Android ACTION_OPEN_DOCUMENT with persistable read permission.
- New images store only the gallery content URI in dream state; no app-side image copy is created.
- Crop is non-destructive and stores normalized zoom/position metadata.
- Legacy IndexedDB image support remains for older data/backups.
