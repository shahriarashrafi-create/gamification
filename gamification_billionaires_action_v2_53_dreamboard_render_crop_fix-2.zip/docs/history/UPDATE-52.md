# Update 52

Fixed crop rendering. Saved crop metadata is now rendered into a transient in-memory preview matching the crop canvas exactly. Added editor preview after Crop. No persistent image duplication.
