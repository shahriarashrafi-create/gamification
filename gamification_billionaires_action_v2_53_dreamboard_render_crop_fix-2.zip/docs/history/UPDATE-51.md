# UPDATE 51 — Gallery/Crop Fix

- Native gallery picker callback now travels through the parent bridge and postMessage.
- WebView can render persisted content:// gallery images through an internal read-only stream endpoint.
- No gallery image bytes are persisted by the app for new images.
- Crop reads the streamed gallery image and saves only zoom/position metadata.
- Persistable read permission handling strengthened.
