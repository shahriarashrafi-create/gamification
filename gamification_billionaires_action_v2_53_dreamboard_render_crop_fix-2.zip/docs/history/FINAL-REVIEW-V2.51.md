# FINAL REVIEW — V2.51

Version 2.51.0 / versionCode 251.

This release fixes the v2.50 gallery reference implementation. The prior version stored content URIs correctly but WebView could not reliably render those URIs directly, which also prevented crop from loading. V2.51 streams the selected content URI through an internal WebView request interceptor without creating a persistent app-side copy.
