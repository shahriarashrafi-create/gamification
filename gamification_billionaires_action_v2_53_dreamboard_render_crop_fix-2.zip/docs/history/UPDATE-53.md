# UPDATE 53

Restored Dreamboard rendering pipeline (`renderBoards`, `renderExplore`, `renderAssets` and related navigation helpers) that was accidentally absent in v2.52. Exact crop display from v2.52 is preserved.
