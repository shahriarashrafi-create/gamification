package com.shahriar.gamification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class FocusAudioService extends Service {
    public static final String ACTION_START = "com.shahriar.gamification.FOCUS_AUDIO_START";
    public static final String ACTION_STOP = "com.shahriar.gamification.FOCUS_AUDIO_STOP";
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_VOLUME = "volume";
    public static final String EXTRA_END_AT = "endAt";

    private static final String CHANNEL_ID = "focus_audio";
    private static final int NOTIFICATION_ID = 2516;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private Runnable finishRunnable;
    private String currentMode = "ocean";
    private int currentVolume = 45;
    private long endAt = 0L;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopEverything();
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action)) {
            currentMode = safeMode(intent.getStringExtra(EXTRA_MODE));
            currentVolume = Math.max(0, Math.min(100, intent.getIntExtra(EXTRA_VOLUME, 45)));
            endAt = intent.getLongExtra(EXTRA_END_AT, System.currentTimeMillis() + 25L * 60L * 1000L);
            long remaining = endAt - System.currentTimeMillis();
            if (remaining <= 0L) {
                stopEverything();
                return START_NOT_STICKY;
            }

            startForeground(NOTIFICATION_ID, buildNotification());
            playLoop(currentMode, currentVolume);
            scheduleFinish(remaining);
            return START_REDELIVER_INTENT;
        }
        return START_NOT_STICKY;
    }

    private String safeMode(String mode) {
        if ("ocean".equals(mode) || "piano".equals(mode) || "forest".equals(mode) || "cafe".equals(mode) || "meditation".equals(mode)) return mode;
        return "ocean";
    }

    private int trackForMode(String mode) {
        if ("piano".equals(mode)) return R.raw.focus_piano;
        if ("forest".equals(mode)) return R.raw.focus_forest;
        if ("cafe".equals(mode)) return R.raw.focus_cafe;
        if ("meditation".equals(mode)) return R.raw.focus_meditation;
        return R.raw.focus_ocean;
    }

    private void playLoop(String mode, int volume) {
        releasePlayer();
        try {
            player = MediaPlayer.create(this, trackForMode(mode));
            if (player == null) return;
            float v = Math.max(0f, Math.min(1f, volume / 100f));
            // Keep the 25-minute ambience intentionally below full volume.
            float shaped = 0.06f + (v * 0.42f);
            player.setVolume(shaped, shaped);
            player.setLooping(true);
            player.start();
        } catch (Exception ignored) {
            releasePlayer();
        }
    }

    private void scheduleFinish(long remainingMs) {
        if (finishRunnable != null) handler.removeCallbacks(finishRunnable);
        finishRunnable = () -> {
            releasePlayer();
            playCompletionAndStop();
        };
        handler.postDelayed(finishRunnable, remainingMs);
    }

    private void playCompletionAndStop() {
        try {
            MediaPlayer completion = MediaPlayer.create(this, R.raw.focus_complete);
            if (completion == null) {
                stopEverything();
                return;
            }
            completion.setVolume(0.55f, 0.55f);
            completion.setOnCompletionListener(mp -> {
                try { mp.release(); } catch (Exception ignored) {}
                stopEverything();
            });
            completion.start();
        } catch (Exception e) {
            stopEverything();
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 16, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String modeFa;
        switch (currentMode) {
            case "piano": modeFa = "پیانو"; break;
            case "forest": modeFa = "جنگل"; break;
            case "cafe": modeFa = "کافه"; break;
            case "meditation": modeFa = "مدیتیشن"; break;
            default: modeFa = "موج دریا";
        }
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_focus_notification)
                .setContentTitle("تمرکز ۲۵ دقیقه‌ای فعال است")
                .setContentText("صدای تمرکز: " + modeFa + " • تایمر در پس‌زمینه ادامه دارد")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "تمرکز ۲۵ دقیقه‌ای",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("صدای پس‌زمینه و وضعیت تایمر تمرکز");
            channel.setSound(null, null);
            manager.createNotificationChannel(channel);
        }
    }

    private void releasePlayer() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    private void stopEverything() {
        if (finishRunnable != null) {
            handler.removeCallbacks(finishRunnable);
            finishRunnable = null;
        }
        releasePlayer();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (finishRunnable != null) handler.removeCallbacks(finishRunnable);
        releasePlayer();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
