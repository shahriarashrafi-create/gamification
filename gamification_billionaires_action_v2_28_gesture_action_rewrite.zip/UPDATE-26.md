# Billionaires Action v2.26

- Mission swipe interaction repaired with Pointer Events and Android-friendly touch handling.
- Complete button repaired; delete button interaction protected above visual layers.
- Top XP HUD replaced by daily completed action count with all-time total underneath.
- Mission card hides Safe/Classic/Rank mode text. R tasks still keep their small R importance marker.
- Mission points chip enlarged.
- Removed the extra “this move +XP” line.
- Existing progress and backup compatibility preserved.
