# Billionaires Action v2.25

- Settings screen compressed and redesigned for smaller Android screens.
- Backup area reduced to Export / Import only.
- Removed version label and ACTION / DISCIPLINE / RANK subtitle.
- Appearance panel reduced to Day / Night plus Game Day start time.
- Sound panel reduced, test-effect control removed, and master sound switch moved beside title.
- Focus ambience options: Ocean, Piano, Forest, Cafe, Meditation.
- Volume control separated from sound selectors to prevent visual overlap.
- Added subtle entrance, glow, sheen, active-state and press animations.
- Existing user data remains compatible; legacy focus sound selections migrate automatically.
