# Final review — v2.25.0

- Settings rebuilt as a compact layout to prevent vertical crowding.
- Backup card now shows only Export / Import.
- App version text and ACTION / DISCIPLINE / RANK subtitle removed from Settings.
- Appearance reduced to Day / Night and the day-start time selector.
- Sound card compressed; master sound switch moved next to the main sound title; test-effect button removed.
- Focus ambience label removed. Available ambience: Ocean, Piano, Forest, Cafe, Meditation.
- Volume row is isolated from ambience buttons so controls do not overlap.
- Legacy focus sound values migrate to the new ambience set.
- Five new loopable OGG ambience files added and native FocusAudioService updated.
- JavaScript syntax check passed; duplicate HTML IDs check passed; Java brace smoke check passed; OGG files verified readable.
- Android versionCode 27 / versionName 2.25.0 and GitHub Actions artifact names synchronized.
