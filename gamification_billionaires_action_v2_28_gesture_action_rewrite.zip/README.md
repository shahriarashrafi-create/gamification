# Billionaires Action — v2.28.0 Gesture + Action Rewrite

نسخه ۱۹ با Quest Deck، Rank مبتنی بر R، XP، Combo یک‌ساعته، Focus 25 دقیقه‌ای ×2، صندوق‌های جایزه، دستاوردها، تنظیمات، Backup، Day/Night و Game Audio.

## صندوق
- روزانه: 4 / 7 / 10 / 15 / 20 اقدام
- هفتگی: 20 / 35 / 50 / 75 / 100 اقدام
- ماهانه: 80 / 150 / 250 / 400 / 600 اقدام
- صندوق آماده را لمس کن تا XP آن دریافت شود.

## روز بازی
روز به‌صورت پیش‌فرض ساعت 06:00 شروع می‌شود. تا قبل از 06:00، تسک‌های روز قبل همچنان فعال هستند. ساعت شروع روز از تنظیمات قابل تغییر است.

## Combo
- 0 تا 4 اقدام: ×1
- 5 تا 9: ×2
- 10 تا 14: ×3
- 15 تا 19: ×4
- 20 به بالا: ×5
- هر اقدام موفق پنجره Combo را یک ساعت تمدید می‌کند.
- حذف تسک یا پایان یک ساعت: Combo = 0.

## Rank
فقط تسک‌های R پیشرفت Rank می‌دهند.

## Focus
تا زمانی که تایمر 25 دقیقه‌ای فعال است، امتیاز همه تسک‌ها ×2 می‌شود.


## v2.24 Final Polish
- کنتراست و خوانایی کامل‌تر در تم روز/شب + محافظت از هم‌پوشانی در نمایشگرهای کوچک.
- صفحه تسک‌ها سبک‌تر با render cache، containment و افکت‌های کم‌هزینه‌تر.
- تنظیمات مرتب‌تر و کم‌ازدحام‌تر با سلسله‌مراتب واضح‌تر.
- هویت بصری Billionaires Action در صفحات و ناوبری یکدست‌تر.
- اصلاح ناسازگاری APP_VERSION داخلی با نسخه پروژه.


## v2.25
Compact animated Settings redesign with new Focus ambience library.


## v2.27
- Fixed mission swipe left/right on Android WebView.
- Restored working Complete action button and kept delete action robust.
- Replaced XP HUD card with daily completed actions + all-time completed actions.
- Removed Safe/Classic/Rank mode labels from the mission card; points are larger and cleaner.
- Removed the “this move +XP” preview line.


## v2.28
- بازنویسی کامل Swipe کارت برای Android WebView بدون فلش.
- اجرای مستقیم دکمه انجام شد/حذف روی touchend با click fallback.
- حذف کامل فلش‌های چپ/راست و کاهش threshold برای swipe.
