# Update 27 — Hard Interaction Fix

- Android touch swipe rebuilt with Touch Events, with Pointer Events only as desktop fallback.
- Complete/Delete actions use capture-phase delegated click handlers.
- Complete commits synchronously, so animation state cannot swallow the action.
- Stale missionSwitching locks are forcibly cleared.
- Left/right navigation arrows are now tappable fallback controls.
- Existing game data remains preserved on update.
