# Update 23 — Achievements / HUD / Mode language

- 13) Achievement claim now triggers a dedicated badge reveal: medal pop, gold ring, stars, confetti, haptic and achievement audio.
- 14) Achievement cards now have four unmistakable states: Locked, In Progress, Ready to Claim, Claimed. Each has its own color, badge and progress treatment.
- 15) The top HUD is more compact on normal and short screens while Level / Rank / XP / Combo stay readable.
- 16) Safe / Classic / Rank now use one color language throughout missions, task cards and mode chips. Rank remains gold and visually prioritized.
- Day/night compatibility retained.
- Existing progress, quests, focus, combo, vaults, backups and achievements remain compatible.
