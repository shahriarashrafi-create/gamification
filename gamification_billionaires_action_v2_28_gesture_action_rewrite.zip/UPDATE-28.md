# Update 28 — Gesture + Action Rewrite

- Swipe engine بازنویسی شد و فقط با کشیدن افقی کارت کار می‌کند.
- فلش‌های ناوبری حذف شدند.
- دکمه انجام شد و حذف روی touchend مستقیم اجرا می‌شوند و click fallback دارند.
- قفل‌های stale interaction پاک می‌شوند.
- نسخه 2.28.0 / versionCode 30.
