# Final Review — V2.52

Version: 2.52.0 (252)

Implemented:
- Per-card background selection using the 10 designed wallpapers.
- Background picker inside the card editor.
- Card ordering controls (one step earlier / send to end).
- Quick move actions added to the card stats menu.
- Bundled the background image assets directly in the app package.
