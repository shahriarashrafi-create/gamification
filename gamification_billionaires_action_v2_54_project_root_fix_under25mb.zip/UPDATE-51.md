# Update 51 — XP Reward Animation

- Mission completion now shows an immediate +XP reward pop on the active card.
- XP reward flies from the mission card to the XP HUD card.
- XP HUD pulses when the reward lands and shows the gained XP.
- Existing Level Up / Rank Up cinematic reward is preserved and starts after the XP flight.
- Reduced-animation setting disables the extra flight effects.
- Version bumped to 2.51.0 / versionCode 251.
