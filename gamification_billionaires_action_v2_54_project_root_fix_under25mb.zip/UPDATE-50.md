# Update 50 — Immersive Focus Mode

- Starting Focus now changes the full game screen into a dedicated focus state.
- The global HUD becomes smaller/dimmer so it stops competing with the current mission.
- The Focus panel grows and shows a larger live countdown and stronger progress bar.
- Bottom navigation is visually de-emphasized while the session is active.
- Current mission gets a teal focus glow, a FOCUS ×2 badge, and highlighted multiplier.
- Stop control becomes the dominant active control; Start is muted while running.
- Focus state automatically ends visually when the timer completes or is stopped.
- Light-theme and reduced-motion compatibility retained.
- Version: 2.50.0 / versionCode 250.
