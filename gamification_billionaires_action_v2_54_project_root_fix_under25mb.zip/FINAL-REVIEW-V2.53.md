# Final Review — V2.53

Version: 2.53.0 (253)

Implemented:
- New setting: choose the main game/home-page background.
- Added a dedicated background selection subpage.
- Added 5 new main page wallpapers.
- Added 5 new task-card wallpapers.
- Card backgrounds total: 15.
- Home backgrounds total: 5 + default.
