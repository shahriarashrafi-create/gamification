# GitHub SDK Fix 2

- Removed `android-actions/setup-android` completely because its default package list requested the obsolete Android SDK package `tools`.
- Uses the `sdkmanager` already present on `ubuntu-latest` and installs only:
  - `platform-tools`
  - `platforms;android-35`
  - `build-tools;35.0.0`
- Keeps Java 17 and Gradle 8.9.
