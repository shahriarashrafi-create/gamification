# Update 54

- Prepared the next ZIP package based on V2.53.
- Version bumped to 2.54.0 / versionCode 254.
- Structure, new card backgrounds, and main page backgrounds are preserved.
- Ready for the next requested feature changes.
