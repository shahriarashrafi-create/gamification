# GitHub Project Root Fix

The workflow now locates `settings.gradle` / `settings.gradle.kts` automatically and builds from that directory. This supports repositories where the Android project was uploaded inside one nested folder instead of directly at repository root.
