# Update 53

- Added home page background selection in Settings.
- Bundled 5 new home page backgrounds under `app/src/main/assets/home_backgrounds/`.
- Added 5 more card backgrounds, increasing the card background set from 10 to 15.
- Home page now applies the selected background visually behind the game screen.
- Background selection is saved instantly in app settings.
- Version bumped to 2.53.0 / versionCode 253.
