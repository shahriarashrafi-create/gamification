# Update 52

- Added 10 bundled card backgrounds under `app/src/main/assets/card_backgrounds/`.
- Each card can now choose its own background from the editor modal.
- Added card ordering controls:
  - one step earlier
  - send to end
- Added the same quick ordering actions to the card stats menu.
- Mission card on the home page now renders the selected background.
- Version bumped to 2.52.0 / versionCode 252.
