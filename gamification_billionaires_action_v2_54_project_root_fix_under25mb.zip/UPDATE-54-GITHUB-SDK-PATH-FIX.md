# GitHub Actions SDK path fix

The workflow no longer assumes `sdkmanager` is on PATH.
It discovers the preinstalled Android SDK command-line tools under `ANDROID_SDK_ROOT`, `ANDROID_HOME`, or `/usr/local/lib/android/sdk`, exports the resolved paths, installs Android 35 packages, and then builds the debug APK.
