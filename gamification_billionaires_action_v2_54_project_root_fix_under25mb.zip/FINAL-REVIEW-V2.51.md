# Final Review — v2.51

Version: 2.51.0 (251)

Validated intent:
- Completion preview score uses the next combo multiplier plus active Focus ×2.
- Reward animation targets the actual XP HUD card.
- XP state and level/rank calculations remain unchanged.
- Reduced-motion/Animations off skips extra reward flight effects.
