# Update 49 — Compact Game HUD

- Built directly on v2.48.0.
- Reduced top HUD height and visual weight.
- Preserved all four tappable HUD cards: Done, Rank, XP, Combo.
- Reduced icon, label, number, and progress-bar footprint.
- Reclaimed vertical space for Focus and the mission card.
- Added responsive compact sizing for narrow and short phones.
- Version bumped to 2.49.0 / versionCode 249.
