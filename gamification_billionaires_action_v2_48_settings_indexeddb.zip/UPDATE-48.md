# Update 48 — Settings + IndexedDB Media

- Settings redesigned into 4 compact cards: Game, Focus, Display, Data & Backup.
- Start hour is now a real settings row with a compact hour picker.
- Pomodoro sound selection opens a dedicated full-screen page; volume lives only on that page.
- Day/Night moved to one display row.
- Added instant Animation on/off setting.
- Import/Export moved into Data & Backup.
- Added Media & Images manager with image count, stored size, and unused-image cleanup.
- Dreamboard and Explore images now use IndexedDB; legacy data-URL images migrate automatically.
- Backups export the actual image data while normal app state stores lightweight media references.
- Added app version row.
- Version bumped to 2.48.0 / versionCode 248.
