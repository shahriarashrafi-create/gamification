# Billionaires Action — v2.21.0 (rebased on v2.19)

نسخه ۱۹ با Quest Deck، Rank مبتنی بر R، XP، Combo یک‌ساعته، Focus 25 دقیقه‌ای ×2، صندوق‌های جایزه، دستاوردها، تنظیمات، Backup، Day/Night و Game Audio.

## صندوق
- روزانه: 4 / 7 / 10 / 15 / 20 اقدام
- هفتگی: 20 / 35 / 50 / 75 / 100 اقدام
- ماهانه: 80 / 150 / 250 / 400 / 600 اقدام
- صندوق آماده را لمس کن تا XP آن دریافت شود.

## روز بازی
روز به‌صورت پیش‌فرض ساعت 06:00 شروع می‌شود. تا قبل از 06:00، تسک‌های روز قبل همچنان فعال هستند. ساعت شروع روز از تنظیمات قابل تغییر است.

## Combo
- 0 تا 4 اقدام: ×1
- 5 تا 9: ×2
- 10 تا 14: ×3
- 15 تا 19: ×4
- 20 به بالا: ×5
- هر اقدام موفق پنجره Combo را یک ساعت تمدید می‌کند.
- حذف تسک یا پایان یک ساعت: Combo = 0.

## Rank
فقط تسک‌های R پیشرفت Rank می‌دهند.

## Focus
تا زمانی که تایمر 25 دقیقه‌ای فعال است، امتیاز همه تسک‌ها ×2 می‌شود.


## v2.20 rebase note
This release returns to the v2.19 feature baseline and only adds the compact Settings/audio changes documented in `UPDATE-20.md`.


## v2.21 HUD + Focus
- HUD labels: Done!, Rank, XP, Combo.
- Done! shows actions completed in the current game day.
- Focus timer uses English digits and icon-only start/stop controls.


## v2.22
Mission HUD cleanup on the v19 rebase: English combo timer/counter, compact multiplier display, and simplified mission metadata.


## v2.23
- Combo multipliers: 2 actions = ×2, 5 = ×3, 8 = ×4, 12 = ×5.
- Combo window is 30 minutes and extends after each completed task.
- Larger English combo timer with tiered animated flame.
- Android notification 2 minutes before combo expiry.
