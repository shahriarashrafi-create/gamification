package com.shahriar.gamification;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.os.SystemClock;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MainActivity extends Activity {
    private WebView webView;
    private long lastBackPressAt = 0L;
    private boolean backCheckInFlight = false;
    private static final long DOUBLE_BACK_WINDOW_MS = 1800L;
    private static final int REQ_EXPORT_BACKUP = 7001;
    private static final int REQ_IMPORT_BACKUP = 7002;
    private String pendingBackupJson = null;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Fresh installs start empty automatically; app updates preserve all game progress.
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 17, 30));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 17, 30));
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setTextZoom(100);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");

        if (savedInstanceState == null) {
            webView.clearCache(true);
            webView.clearHistory();
            webView.loadUrl("file:///android_asset/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private class BackupBridge {
        @JavascriptInterface
        public void exportBackup(String json) {
            pendingBackupJson = json;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "gamification-backup.json");
                startActivityForResult(intent, REQ_EXPORT_BACKUP);
            });
        }

        @JavascriptInterface
        public void importBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQ_IMPORT_BACKUP);
            });
        }
    }

    private void jsMessage(String message) {
        if (webView == null) return;
        String quoted = JSONObject.quote(message == null ? "" : message);
        webView.evaluateJavascript("typeof nativeBackupMessage==='function' ? nativeBackupMessage(" + quoted + ") : false", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_EXPORT_BACKUP) {
                if (pendingBackupJson == null) { jsMessage("بک‌آپی برای ذخیره وجود ندارد"); return; }
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new Exception("output");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackupJson = null;
                jsMessage("بک‌آپ ذخیره شد");
            } else if (requestCode == REQ_IMPORT_BACKUP) {
                StringBuilder sb = new StringBuilder();
                try (InputStream in = getContentResolver().openInputStream(uri); BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line).append('\n');
                }
                String quoted = JSONObject.quote(sb.toString());
                webView.evaluateJavascript("typeof importBackupFromNative==='function' ? importBackupFromNative(" + quoted + ") : false", null);
            }
        } catch (Exception e) {
            jsMessage("خطا در عملیات بک‌آپ");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "typeof resumeFromBackground==='function' ? resumeFromBackground() : false",
                    null
            ));
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "typeof prepareForBackground==='function' ? prepareForBackground() : true",
                    null
            );
        }
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView == null || backCheckInFlight) return;
        backCheckInFlight = true;

        webView.evaluateJavascript(
                "(function(){var p=document.querySelector('.page.active');return p?p.id:'home';})()",
                value -> {
                    backCheckInFlight = false;
                    String page = value == null ? "home" : value.replace("\"", "").trim();

                    if (!"home".equals(page)) {
                        lastBackPressAt = 0L;
                        webView.evaluateJavascript(
                                "typeof goToPage==='function' ? goToPage('home') : 'home'",
                                null
                        );
                        return;
                    }

                    long now = SystemClock.elapsedRealtime();
                    if (now - lastBackPressAt <= DOUBLE_BACK_WINDOW_MS) {
                        lastBackPressAt = 0L;
                        webView.evaluateJavascript(
                                "typeof prepareForBackground==='function' ? prepareForBackground() : true",
                                null
                        );
                        // Put the app in the background instead of destroying it. The focus timer
                        // is timestamp-based, so its progress remains valid while the app is away.
                        moveTaskToBack(true);
                    } else {
                        lastBackPressAt = now;
                        Toast.makeText(this, "برای خروج دوباره دکمه برگشت را بزن", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }
}
