# Update 28 — Pinch Zoom + Light Contrast + HD Audio

Base: v2.27 on the v19 rebase branch.

## TimeSheet
- Removed the Persian subtitle below TimeSheet.
- Removed + / - zoom controls.
- Added two-finger pinch zoom to the weekly board.
- Zoom range is 50% to 150%; zoom persists in saved state.
- A small temporary percentage badge appears only while pinching.

## Settings / Light Theme
- Settings title is now English and the gear sits on the left.
- Improved contrast for light mode across primary cards, HUD, navigation, task cards, mission UI, vault, achievements, settings, forms, modals, and TimeSheet.

## Focus Audio
- Simplified labels to موج دریا / پیانو / جنگل / صدای آدم‌ها.
- Rebuilt all ten 30-second focus loops as 48 kHz stereo higher-quality OGG files.
- Rain, ocean, forest, fire, crowd, meditation, flow, pulse, and arcade were procedurally rebuilt with richer stereo texture.
- Piano was newly synthesized from a Bach Prelude in C major inspired/public-domain note progression for this app; no third-party recording is bundled.
