# Final Review — v2.38

- Base: v2.37 rebase-on-v19 branch.
- Added «لیست افراد و اقدامات» to Tree > PV / GPV under PV, GPV and تعداد.
- Integrated Network CRM/List v1.7 as an in-app page inside the Tree hub.
- Gamification dark/light theme is propagated into the list page.
- Tree people sync into the list using tree person IDs/names and do not create duplicates.
- List contacts, stages, done/repeat state, notes and list gamification state persist and are included in main backup/export.
- Back control returns from the list page to the Tree PV/GPV screen.
- Native contact picker, dialer, SMS and Telegram hooks are exposed to the integrated list page.
- CSV/VCF file chooser is preserved alongside image selection for Dreamboard.
- JavaScript syntax checks: PASS.
- Duplicate static HTML IDs: none.
- Manifest XML parse: PASS.
- ZIP integrity: to be checked after packaging.
