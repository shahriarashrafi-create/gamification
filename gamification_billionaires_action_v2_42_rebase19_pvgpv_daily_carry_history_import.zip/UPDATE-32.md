# Update 32 — PV / GPV Clean Layout

Base: v2.31 on the v19 rebase branch.

- Removed “1 of N” person position text from PV / GPV cards.
- Removed the “swipe between people” hint.
- Field labels are now PV :, GPV :, and تعداد :, aligned on the left with values beside them.
- PV / GPV page now consumes the full available embedded height to avoid extra vertical scrolling.
