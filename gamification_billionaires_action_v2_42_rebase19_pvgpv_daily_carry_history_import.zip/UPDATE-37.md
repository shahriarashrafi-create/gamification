# Update 37 — Daily PV/GPV + TimeSheet Free Pan + Compact Dream Controls

- PV / GPV / count entry is treated as a new daily entry. Existing v2.36 values are preserved on first migration; starting with the following calendar day the three daily numbers reset to zero for every person and must be entered again.
- Tapping a PV/GPV/count number selects the current value for immediate replacement.
- Save commits that person to today's daily archive and advances to the next person, focusing the next numeric field.
- TimeSheet keeps two-finger pinch zoom and adds explicit one-finger free panning vertically and horizontally across the zoomed board.
- Dream-board per-image three-dot and achieved-circle controls are smaller.
