# Update 27 — TimeSheet Zoom + Reminder

Base: v2.26 rebase-on-v19 with TimeSheet v7 integrated.

## Changes
- Zoom Out / Zoom In controls added to TimeSheet; persisted range is 70% to 150%.
- Removed dates from the week navigation title.
- Week title is now relative: «این هفته»، «یک هفته بعد»، «دو هفته قبل» and so on.
- An icon-only ↺ control appears outside the current week and returns directly to this week.
- Removed the «نمای کلی» option and its modal.
- Added per-program «یادآوری ۵ دقیقه قبل» checkbox, disabled by default.
- Android notification scheduling uses AlarmManager and survives the app being closed.
- Weekly recurring programs with reminders reschedule their next reminder automatically.
