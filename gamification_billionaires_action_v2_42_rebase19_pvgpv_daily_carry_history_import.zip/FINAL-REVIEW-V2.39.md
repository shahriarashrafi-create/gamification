# Final Review — v2.39

- Version name: 2.39.0
- Version code: 50
- Base: v2.38 rebase-on-v19 branch
- Combo reminder: 5 minutes before expiry
- PV/GPV People & Actions label enlarged
- Quick Direct add: name-only, adds under the currently viewed tree person
- People & Actions rebuilt into 4 labeled tabs
- Default tab on every open: Register New Prospect
- Action summary: prospect, action, date, expandable result
- People list: name-only rapid add, only prospects with no action
- Team networking: automatic feed from tree networking actions + synced list actions
- List actions are linked to the tree referrer and synced back to tree data
- JavaScript syntax checks: PASS
- Duplicate static HTML IDs: none
