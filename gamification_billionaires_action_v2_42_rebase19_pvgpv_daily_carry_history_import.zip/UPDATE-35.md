# Update 35 — Dream Board Refinement

Base: v2.34 on the v19 rebase branch.

- Fixed Persian year formatting to use ungrouped digits: ۱۴۰۵, not ۱٬۴۰۵.
- Year text itself now opens year editing.
- Removed the standalone year three-dot button.
- The final-year forward arrow becomes + for adding the next year.
- Removed year subtitle/short-title editing and made the year bar more compact.
- Enlarged dream add/edit modal and controls.
- Dream fields: عنوان رویا / ارزش هدف / عکس / Crop / وضعیت تحقق.
- Removed dream descriptions and categories, including category filters from Explore.
- Gallery selection uses an «انتخاب عکس» button; the raw file input is hidden.
- Added «حذف عکس» beside image selection.
- Added interactive Crop (drag + zoom), applied only after confirmation.
