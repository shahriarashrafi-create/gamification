# Update 42 — PV / GPV Daily Carry + History Import Repair

Base: v2.41 on the v19 rebase branch.

## PV / GPV daily behavior
- PV, GPV, and active-count values no longer reset to zero when the calendar day changes.
- On a new day, each person starts with the latest values from the previous saved daily snapshot.
- Those carried values become today's snapshot automatically; changing and saving a person's numbers replaces only today's values.
- If the app was not opened for multiple days, the most recent prior snapshot is used as the carry-forward source.

## Export / Import history
- Tree daily history is normalized and restored as a first-class part of the full backup.
- Backup schema is now 3 and stores the Tree daily archive redundantly as `archive`, `dailyHistory` / `dailySnapshots`, plus a top-level `treeDailyHistory` mirror for recovery.
- Import restores all historical PV / GPV / active-count snapshots before creating/updating today's snapshot.
- Historical comparison date selections are validated against the imported archive so stale date keys do not hide restored data.
- Legacy Tree backups that contain `archive` continue to import.
