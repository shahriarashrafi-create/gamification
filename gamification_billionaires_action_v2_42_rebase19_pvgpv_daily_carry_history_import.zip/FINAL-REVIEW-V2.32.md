# Final Review — v2.32

- Version: 2.32.0
- Version code: 43
- Base: v2.31
- PV / GPV person counter removed
- Swipe hint removed
- Horizontal compact PV / GPV / count rows
- Full-height PV / GPV card layout
