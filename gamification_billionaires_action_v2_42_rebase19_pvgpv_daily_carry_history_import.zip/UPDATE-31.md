# Update 31 — Card-first Gameplay

Base: v2.30 on the v19 rebase branch.

## Game
- Removed the Tasks page.
- Tapping a card name opens its 30-day statistics.
- Statistics include per-day done/not-done state, current scheduled streak, and total completions.
- Three-dot menu at the top-right of card statistics opens card editing, new-card creation, or permanent deletion.
- Return to first card now uses ⏪️.

## Card editor
- Name
- Short description
- Base points
- Weekday recurrence selector
- No mode, tag, frequency dropdown, or default status.
- Base points >= 30 automatically count as Rank actions.

## Migration
- Existing cards keep names, descriptions, points and progress.
- Legacy mode/tag/enabled/frequency fields are retired.
- Existing streak/last-done information is used to seed per-card history where possible.
- Mode-only achievements are retired.
