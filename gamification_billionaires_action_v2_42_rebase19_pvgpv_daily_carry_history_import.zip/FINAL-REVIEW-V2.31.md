# Final Review — v2.31

- Version name: 2.31.0
- Version code: 42
- Standalone Tasks page: removed
- Main navigation: 5 items
- Per-card 30-day stats: implemented
- Three-dot card menu: implemented
- Weekday recurrence: implemented
- Rank rule: base points >= 30
- Modes/tags/default card status: removed from active game UI and logic
- First-card control: ⏪️

- JavaScript syntax: PASS
- Chromium mobile interaction smoke test: PASS
- 30-day grid count: 30
- Card menu position: top-right verified
- Legacy mode-only UI fields: absent
