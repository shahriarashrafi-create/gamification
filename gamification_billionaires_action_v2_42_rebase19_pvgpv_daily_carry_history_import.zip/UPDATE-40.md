# Update 40 — Scoped people/actions + navigation reset

- Android Back is now a three-step sequence: current section root -> Game -> exit/background.
- Tapping any bottom navigation tab always opens that section at its root page.
- Removed the Tree one-finger/two-finger instruction text.
- PV/GPV cards no longer dim non-current people; visual treatment is consistent for everyone.
- “لیست افراد و اقدامات” and “اضافه کردن دایرکت” use the same larger typography and height.
- People/actions workspace is isolated per tree person.
- Action summary shows only that person’s own registered actions.
- People list is isolated per person and supports deletion.
- Team networking feed shows only actions created by descendants in that person’s subtree, excluding the person themself and outsiders.
