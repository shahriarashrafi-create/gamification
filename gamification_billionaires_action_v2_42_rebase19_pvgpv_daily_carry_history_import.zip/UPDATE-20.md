# Update 20 — Rebase on v2.19 + Compact Settings

This release is intentionally based on the v2.19 codebase. All product changes introduced after v2.19 were discarded, except for the settings refinements listed here.

## Settings
- Compact Import / Export only backup panel.
- Removed backup descriptions/status text from the visible UI.
- Compact Day / Night appearance selector.
- Game-day start time moved into its own compact card.
- Compact game-audio panel with the sound on/off control beside the title.
- Removed sound test button and the visible “25-minute sound” label.
- Kept a separate volume slider that does not overlap the sound picker.
- Removed visible app version from Settings.
- Added six focus ambience choices: deep ocean, piano, peaceful forest, firewood, crowd ambience, meditation.
- Existing focus sounds are kept.
- All focus ambience tracks are exactly 30 seconds and loop while Focus is active.

## Compatibility
- versionName: 2.20.0
- versionCode: 31, intentionally higher so this v2.19-based release can be installed over later experimental builds without an Android downgrade error.
