# Update 41 — Full Backup + Editable People/Actions

Base: v2.40 on the v19 rebase branch.

## Full Export / Import
- Export captures the full primary state plus current embedded Tree, Dream Board, and List snapshots.
- TimeSheet lives in core state and is explicitly mirrored in the backup sections.
- Tree backup includes people, daily archive, comparison selections, history date selections, zoom, daily-entry day, current selection, collapsed branches, and current list owner.
- List backup includes all contacts/actions, game/list scoring data, and list UI state.
- Dream Board backup includes years, dreams, images/crops, assets, and its persisted state.
- Import restores sections and re-syncs embedded modules after loading.

## Back behavior
- First Back closes parent modals and nested section windows, then returns to the root of the current section.
- Tree reset also resets/cleans the nested People & Actions workspace.
- Second Back returns to Game; third Back exits as before.

## People & Actions
- Action Summary now has an edit control for prospect name, action type, result, and date.
- Edited actions stay synchronized with Tree networking history, including renamed prospects.
- People List now has edit + delete controls for each owner-scoped person.
- Both areas have larger, clearer, gamified cards with improved light-theme contrast.
