# Update 39

- Combo expiry notification now fires 5 minutes before expiry.
- Larger People & Actions label in PV/GPV.
- Added quick Direct member creation under the current tree person.
- Rebuilt People & Actions into four labeled tabs: register prospect, action summary, people without actions, and automatic team networking feed.
- Prospect actions are linked to the tree referrer and synchronized back into tree networking data.
