# Update 34 — Single-Year Dream Carousel

- Dream Board now shows one year at a time instead of a grid of every year.
- Previous/next year navigation is handled by arrow buttons and the selected year is saved.
- Dreams in the selected year are displayed one at a time as full-area image cards.
- Horizontal swipe/scroll moves between dreams in the same year with snap-to-card behavior.
- Dream title and dollar value are overlaid at the bottom of each image.
- Per-dream edit and completion controls remain available as compact overlay icons.
- Add-dream is the final horizontal slide; add/edit year controls remain in the compact year header.
- Explore opens the relevant year and scrolls directly to the selected dream.
