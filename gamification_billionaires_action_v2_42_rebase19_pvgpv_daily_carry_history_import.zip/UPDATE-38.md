# Update 38 — People & Actions inside Tree

- Added «لیست افراد و اقدامات» under PV / GPV / تعداد on the Tree PV/GPV card.
- Opens an integrated CRM/list experience based on Network CRM v1.7.
- Integrated page follows Gamification dark/light theme and lives inside the existing Tree area.
- Tree people are synchronized into the list by name/id without duplicate insertion.
- List contacts, stages, completion/repeat state, notes and gamified list data persist and are included in the main Gamification backup.
- Back button returns to the Tree PV/GPV view.
