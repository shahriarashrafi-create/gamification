# Final Review — v2.35

- Version name: 2.35.0
- Version code: 46
- Base: v2.34 / v19 rebase branch
- Ungrouped year display: implemented
- Year click opens editor: implemented
- Last-year arrow -> add button: implemented
- Year short title: removed from UI
- Larger dream editor: implemented
- Dream description/category: removed from UI
- Explore category filters/labels: removed
- Custom gallery chooser button + remove photo: implemented
- Editor image preview: removed
- Crop: implemented with one-finger pan and zoom slider
