# Final Review — v2.18.0

## Requested behavior checked
- Top HUD: Level / Rank / XP / Combo.
- B tag removed from task editor, initial tasks, migration, mission cards and task cards.
- Existing B tasks migrate to normal tasks without deleting the task itself.
- Rank progress is strictly tied to `R` tasks.
- Rank-mode tasks are normalized to `R`, and saving a Rank task automatically marks it `R`.
- 25-minute Focus remains; while active it gives exactly `×2` points.
- Focus no longer levels up or applies a variable magic multiplier.
- Combo window uses an absolute one-hour expiry timestamp, so it survives backgrounding.
- Each successful task extends Combo by one hour.
- Combo multipliers: 5→×2, 10→×3, 15→×4, 20+→×5.
- Focus and Combo multiply together.
- Deleting a task resets Combo immediately.
- Combo expiration resets it to zero.
- Home/deck has a return-to-first-pending-task button.
- Removed visible “ماموریت فعلی” and swipe instruction text.
- Card transition animation upgraded.
- Level-up animation/sound upgraded.
- Rank-up animation/sound upgraded substantially.

## Static checks
- JavaScript syntax checked with Node.js.
- All `getElementById(...)` references resolve to existing DOM IDs.
- Existing storage key is preserved so upgrading does not wipe progress.
- Old backups remain importable; old B tags are normalized away.
