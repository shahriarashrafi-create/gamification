# Final Review — v2.37

- Version name: 2.37.0
- Version code: 48
- Daily tree input rollover: implemented
- PV/GPV save-to-today + next person: implemented
- TimeSheet one-finger free pan: implemented
- TimeSheet two-finger pinch: preserved
- Dream overlay controls: compacted
