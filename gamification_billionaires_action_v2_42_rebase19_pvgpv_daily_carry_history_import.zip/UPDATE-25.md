# Update 25 — Fire Timer + HUD Stats

Base: v2.24 rebase-on-v19.

## Changes
- Removed campfire wood/log visuals from the combo timer.
- The entire combo timer pill now behaves like a professional animated flame surface.
- Flame intensity and speed increase across combo tiers.
- Done!, Rank, XP, and Combo HUD cards are now interactive.
- Each HUD card opens its own animated statistics panel with relevant progress and totals.
- No post-v19 branch features were reintroduced beyond the requested rebase updates.

## Validation
- Inline JavaScript syntax checked with Node.
- HUD-card modal interactions tested in Chromium at a mobile viewport.
- Combo fire field/timer render tested with an active combo state.
