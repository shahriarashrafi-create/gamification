# Final Review — v2.40

- Version name: 2.40.0
- Version code: 51
- Base: v2.39 / rebase-on-v19 branch
- Scoped list/actions per tree owner: implemented
- Descendant-only team feed: implemented
- Delete from per-owner people list: implemented
- Bottom nav root reset: implemented
- Three-step back flow: implemented
- Tree hint removed and PV card opacity normalized
