# Update 36 — Dreamboard Minimal Crop

Base: v2.35.

- Removed photo title/status text and the dedicated Crop panel from the dream editor.
- Added an icon-only crop button between Select Photo and Remove Photo.
- Removed the achieved checkbox from the dream editor.
- Added an icon-only hollow completion circle on each dream card; it turns into a check when achieved.
- Increased year title size.
- Crop UI now contains only `Crop`, image, and × / ↺ / ✓ controls.
- Removed zoom range input and help text.
- Two-finger pinch zoom and one-finger pan implemented.
- Reset returns image transform to its initial crop state.
- Photo selection preserves original source data; crop exports only the selected source-pixel region without pre-resizing.
