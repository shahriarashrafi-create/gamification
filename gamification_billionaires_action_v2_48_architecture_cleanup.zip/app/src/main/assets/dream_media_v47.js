(function(global){
'use strict';
const DB_NAME='billionaires-action-media';
const DB_VERSION=1;
const STORE='images';
const PREFIX='idb:';
let dbPromise=null;
const urlCache=new Map();
function keyFromRef(ref){ref=String(ref||'');return ref.startsWith(PREFIX)?ref.slice(PREFIX.length):ref}
function refFromKey(key){return PREFIX+String(key||'')}
function isRef(value){return typeof value==='string'&&value.startsWith(PREFIX)}
function makeKey(){return 'img-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10)}
function open(){
 if(dbPromise)return dbPromise;
 dbPromise=new Promise((resolve,reject)=>{
  if(!global.indexedDB){reject(new Error('IndexedDB unavailable'));return}
  const req=indexedDB.open(DB_NAME,DB_VERSION);
  req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'key'})};
  req.onsuccess=()=>resolve(req.result);
  req.onerror=()=>reject(req.error||new Error('IndexedDB open failed'));
 });
 return dbPromise;
}
async function tx(mode,work){const db=await open();return new Promise((resolve,reject)=>{const t=db.transaction(STORE,mode),s=t.objectStore(STORE);let result;try{result=work(s,t)}catch(e){reject(e);return}t.oncomplete=()=>resolve(result);t.onerror=()=>reject(t.error||new Error('IndexedDB transaction failed'));t.onabort=()=>reject(t.error||new Error('IndexedDB transaction aborted'))})}
async function putBlob(blob,preferredRef){if(!(blob instanceof Blob))throw new Error('Invalid image blob');const key=isRef(preferredRef)?keyFromRef(preferredRef):(preferredRef?String(preferredRef):makeKey());await tx('readwrite',s=>s.put({key,blob,updatedAt:Date.now()}));const ref=refFromKey(key);revoke(ref);return ref}
async function getBlob(ref){if(!isRef(ref))return null;const db=await open();return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readonly'),r=t.objectStore(STORE).get(keyFromRef(ref));r.onsuccess=()=>resolve(r.result&&r.result.blob instanceof Blob?r.result.blob:null);r.onerror=()=>reject(r.error||new Error('IndexedDB read failed'))})}
async function getUrl(ref){if(!ref)return'';if(!isRef(ref))return String(ref);if(urlCache.has(ref))return urlCache.get(ref);const blob=await getBlob(ref);if(!blob)return'';const url=URL.createObjectURL(blob);urlCache.set(ref,url);return url}
function revoke(ref){const url=urlCache.get(ref);if(url){try{URL.revokeObjectURL(url)}catch(_){ }urlCache.delete(ref)}}
async function remove(ref){if(!isRef(ref))return;revoke(ref);await tx('readwrite',s=>s.delete(keyFromRef(ref)))}
async function allKeys(){const db=await open();return new Promise((resolve,reject)=>{const t=db.transaction(STORE,'readonly'),s=t.objectStore(STORE),out=[];if(s.getAllKeys){const r=s.getAllKeys();r.onsuccess=()=>resolve((r.result||[]).map(String));r.onerror=()=>reject(r.error)}else{const r=s.openKeyCursor();r.onsuccess=e=>{const c=e.target.result;if(c){out.push(String(c.key));c.continue()}else resolve(out)};r.onerror=()=>reject(r.error)}})}
async function prune(liveRefs){const keep=new Set((liveRefs||[]).filter(isRef).map(keyFromRef));const keys=await allKeys();for(const key of keys){if(!keep.has(key))await remove(refFromKey(key))}}
function dataUrlToBlob(dataUrl){const raw=String(dataUrl||''),m=raw.match(/^data:([^;,]+)?(;base64)?,(.*)$/s);if(!m)throw new Error('Invalid data URL');const mime=m[1]||'application/octet-stream',body=m[3]||'';let bytes;if(m[2]){const bin=atob(body);bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i)}else{const text=decodeURIComponent(body);bytes=new TextEncoder().encode(text)}return new Blob([bytes],{type:mime})}
function blobToDataUrl(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(r.error||new Error('Blob read failed'));r.readAsDataURL(blob)})}
async function migrateDataUrl(dataUrl,preferredRef){const blob=dataUrlToBlob(dataUrl);return putBlob(blob,preferredRef)}
async function exportArchive(refs){const archive={};for(const ref of [...new Set((refs||[]).filter(isRef))]){const blob=await getBlob(ref);if(blob)archive[ref]=await blobToDataUrl(blob)}return archive}
async function importArchive(archive){if(!archive||typeof archive!=='object')return;for(const [ref,dataUrl] of Object.entries(archive)){if(!isRef(ref)||typeof dataUrl!=='string'||!dataUrl.startsWith('data:'))continue;try{await putBlob(dataUrlToBlob(dataUrl),ref)}catch(_){ }} }
global.DreamMedia={isRef,putBlob,getBlob,getUrl,remove,prune,migrateDataUrl,exportArchive,importArchive,blobToDataUrl,dataUrlToBlob};
})(window);
