const STAGES = {
  connect: { label: 'ارتباط‌سازی', icon: 'i-users', className: 'connect', points: 10 },
  preconsult: { label: 'پیش‌مشاوره', icon: 'i-message', className: 'preconsult', points: 25 },
  invite: { label: 'دعوت', icon: 'i-send', className: 'invite', points: 50 },
  followup: { label: 'فالوآپ', icon: 'i-sprout', className: 'followup', points: 100 },
};

const makeId = () => (globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random().toString(16).slice(2)}`);
const now = Date.now();
const seed = [
  {id:makeId(),name:'علی محمدی',phone:'0912 345 6789',stage:'connect',note:'معرفی از طرف حسین',done:false,createdAt:now-5_000},
  {id:makeId(),name:'سارا رضایی',phone:'0935 987 6543',stage:'preconsult',note:'علاقه‌مند به اطلاعات بیشتر',done:true,createdAt:now-10_000},
  {id:makeId(),name:'مهدی احمدی',phone:'0919 111 2233',stage:'invite',note:'دعوت برای جلسه شنبه',done:false,createdAt:now-15_000},
  {id:makeId(),name:'نرگس کریمی',phone:'0912 444 5566',stage:'followup',note:'پیگیری سه‌شنبه',done:false,createdAt:now-20_000},
  {id:makeId(),name:'رضا قاسمی',phone:'0930 777 8899',stage:'connect',note:'',done:false,createdAt:now-25_000},
  {id:makeId(),name:'الهام موسوی',phone:'0912 222 3344',stage:'preconsult',note:'',done:false,createdAt:now-30_000},
  {id:makeId(),name:'حمید نادری',phone:'0936 555 6677',stage:'',note:'از مخاطبین گوشی',done:false,createdAt:now-35_000},
  {id:makeId(),name:'کامران عباسی',phone:'0919 888 7766',stage:'followup',note:'منتظر پاسخ',done:false,createdAt:now-40_000},
];

const storageKey = 'networkCRM.contacts.v3';
let stored = JSON.parse(localStorage.getItem(storageKey) || 'null');
if (!stored) {
  const previous = JSON.parse(localStorage.getItem('networkCRM.contacts.v2') || 'null') || JSON.parse(localStorage.getItem('networkCRM.contacts') || 'null');
  if (Array.isArray(previous)) {
    stored = previous.map(c => ({
      ...c,
      stage: c.stage === 'reference' ? '' : (c.stage || ''),
      done: Boolean(c.done),
    }));
  }
}
function normalizeContact(c){
  const done = Boolean(c.done);
  const fallbackPoints = c.stage ? (STAGES[c.stage]?.points || 10) : 5;
  let currentReward = null;
  if(c.currentReward && Number(c.currentReward.points) > 0){
    currentReward = {points:Number(c.currentReward.points), date:String(c.currentReward.date || '')};
  }else if(done){
    // داده‌های نسخه‌های قبلی تاریخ پاداش را نداشتند؛ مقدار مرحله برای امکان پس‌گرفتن امتیاز نگه داشته می‌شود.
    currentReward = {points:fallbackPoints, date:''};
  }
  return {
    ...c,
    done,
    repeatNeeded:Boolean(c.repeatNeeded),
    currentReward,
    rewardedStages:Array.isArray(c.rewardedStages)?c.rewardedStages:[],
    actions:Array.isArray(c.actions)?c.actions:[],
    referrerTreePersonId:c.referrerTreePersonId==null?null:Number(c.referrerTreePersonId),
    referrerName:String(c.referrerName||'')
  };
}
let contacts = Array.isArray(stored)
  ? stored.map(normalizeContact)
  : [];
let activeStage = 'all';
let stageTargetIds = [];
let actionTargetId = null;
let filters = { stage: 'all', note: 'any', done: 'any' };

const gameStorageKey = 'networkCRM.game.v1';
const XP_PER_LEVEL = 1000;
const DAILY_MISSION_TARGET = 5;
const dayKey = (d=new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const defaultGame = () => ({
  totalXp: 11730,
  todayPoints: 280,
  streak: 5,
  todayCompletions: 3,
  todayDate: dayKey(),
  lastActivityDate: dayKey(),
});
let game = {...defaultGame(), ...(JSON.parse(localStorage.getItem(gameStorageKey) || 'null') || {})};

function normalizeGameDay(){
  const today = dayKey();
  if(game.todayDate !== today){
    game.todayDate = today;
    game.todayPoints = 0;
    game.todayCompletions = 0;
  }
}
normalizeGameDay();

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const fa = n => Number(n).toLocaleString('fa-IR');
const escapeHTML = (s='') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials = name => String(name || '').trim().split(/\s+/).slice(0,2).map(x=>x[0] || '').join('');
const icon = id => `<svg aria-hidden="true"><use href="#${id}"/></svg>`;

function integratedPayload(){return{contacts:contacts.map(c=>({...c})),game:{...game}}}
function emitIntegratedState(){try{window.top.postMessage({type:'list-state',payload:integratedPayload()},'*')}catch(_){}}
function save(){ localStorage.setItem(storageKey, JSON.stringify(contacts)); emitIntegratedState(); }
function saveGame(){ localStorage.setItem(gameStorageKey, JSON.stringify(game)); emitIntegratedState(); }
function awardGamePoints(amount=20){
  normalizeGameDay();
  const today = dayKey();
  const yesterday = dayKey(new Date(Date.now() - 86400000));
  if(game.lastActivityDate !== today){
    game.streak = game.lastActivityDate === yesterday ? Math.max(1, Number(game.streak||0) + 1) : 1;
    game.lastActivityDate = today;
  }
  game.totalXp = Number(game.totalXp||0) + amount;
  game.todayPoints = Number(game.todayPoints||0) + amount;
  game.todayCompletions = Number(game.todayCompletions||0) + 1;
  saveGame();
  return today;
}
function deductGamePoints(amount=0, awardedDate=''){
  const points = Math.max(0, Number(amount||0));
  if(!points) return;
  normalizeGameDay();
  game.totalXp = Math.max(0, Number(game.totalXp||0) - points);
  if(awardedDate && awardedDate === dayKey()){
    game.todayPoints = Math.max(0, Number(game.todayPoints||0) - points);
    game.todayCompletions = Math.max(0, Number(game.todayCompletions||0) - 1);
  }
  saveGame();
}
function toast(msg){
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._timer);
  el._timer = setTimeout(()=>el.classList.remove('show'), 2300);
}
function openDialog(id){ const d=$(id); if(d && !d.open) d.showModal(); }
function closeDialog(id){ const d=$(id); if(d?.open) d.close(); }

function renderStats(){
  const stats = [
    {key:'all', label:'همه', icon:'i-users', className:'all', count:contacts.length},
    ...Object.entries(STAGES).map(([key,s])=>({key,label:s.label,icon:s.icon,className:s.className,count:contacts.filter(c=>c.stage===key).length}))
  ];
  $('#stats').innerHTML = stats.map(s => `
    <button type="button" class="stat ${s.className} ${activeStage===s.key?'active':''}" data-stat-stage="${s.key}" title="${escapeHTML(s.label)}">
      ${icon(s.icon)}<span class="label">${escapeHTML(s.label)}</span><span class="num">${fa(s.count)}</span>
    </button>`).join('');
  $$('[data-stat-stage]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.statStage;
    render();
  });
}

function renderGamification(){
  normalizeGameDay();
  const totalXp = Math.max(0, Number(game.totalXp||0));
  const level = Math.floor(totalXp / XP_PER_LEVEL) + 1;
  const xpInLevel = totalXp % XP_PER_LEVEL;
  const xpPercent = Math.max(0, Math.min(100, (xpInLevel / XP_PER_LEVEL) * 100));
  $('#levelNumber').textContent = fa(level);
  $('#xpFill').style.width = `${xpPercent}%`;
  $('#streakDays').textContent = fa(Math.max(0, Number(game.streak||0)));
  $('#todayScore').textContent = fa(Math.max(0, Number(game.todayPoints||0)));
}


function renderTabs(){
  const items = [{key:'all',label:'همه'}, ...Object.entries(STAGES).map(([key,v])=>({key,label:v.label}))];
  $('#stageTabs').innerHTML = items.map(x=>`<button class="stage-tab ${activeStage===x.key?'active':''}" data-stage-tab="${x.key}">${x.label}</button>`).join('');
  $$('[data-stage-tab]').forEach(btn => btn.onclick = () => {
    activeStage = btn.dataset.stageTab;
    filters.stage = 'all';
    $('#filterStage').value = 'all';
    render();
  });
}

function visibleContacts(){
  const arr = contacts.filter(c => activeStage === 'all' || c.stage === activeStage);
  arr.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
  return arr;
}

function badgeFor(c){
  if (!c.stage) return `<button class="badge none" data-stage-change="${c.id}" title="انتخاب مرحله">${icon('i-users')}<span>بدون مرحله</span></button>`;
  const s=STAGES[c.stage];
  return `<button class="badge ${s?.className || 'none'}" data-stage-change="${c.id}" title="تغییر مرحله">${icon(s?.icon || 'i-users')}<span>${escapeHTML(s?.label || 'بدون مرحله')}</span></button>`;
}

function relativeActivity(c){
  if(c.done) return 'انجام‌شده در این مرحله';
  if(c.note?.trim()) return c.note.trim();
  const days = Math.max(0, Math.floor((Date.now() - Number(c.createdAt || Date.now())) / 86400000));
  if(days <= 0) return 'امروز اضافه شده';
  if(days === 1) return '۱ روز پیش';
  return `${fa(days)} روز پیش`;
}

function renderContacts(){
  const arr = visibleContacts();
  if(!arr.length){
    $('#contacts').innerHTML = `<div class="empty"><strong>مخاطبی در این بخش نیست</strong>از دکمه + مخاطب جدید اضافه کن یا از کارت‌های بالا مرحله دیگری را انتخاب کن.</div>`;
    return;
  }

  $('#contacts').innerHTML = arr.map(c => `
    <article class="contact ${c.done?'done':''}" data-contact-row="${c.id}">
      <input class="done-check" type="checkbox" aria-label="${c.done?'برداشتن تیک':'علامت انجام شد برای'} ${escapeHTML(c.name)}" data-done="${c.id}" ${c.done?'checked':''} />
      <div class="info">
        <div class="name">${escapeHTML(c.name)}</div>
        <div class="quick-actions" aria-label="راه‌های ارتباطی">
          <button type="button" data-call="${c.id}" aria-label="تماس با ${escapeHTML(c.name)}" title="تماس">${icon('i-phone')}</button>
          <button type="button" data-sms="${c.id}" aria-label="پیامک به ${escapeHTML(c.name)}" title="پیامک">${icon('i-sms')}</button>
          <button type="button" class="telegram" data-telegram="${c.id}" aria-label="تلگرام ${escapeHTML(c.name)}" title="تلگرام">${icon('i-telegram')}</button>
        </div>
      </div>
      <div class="stage-side">
        ${badgeFor(c)}
        <button type="button" class="repeat-btn ${c.repeatNeeded?'active':''}" data-repeat="${c.id}" aria-label="${c.repeatNeeded?'لغو نیاز به انجام دوباره':'این مرحله دوباره باید انجام شود'} برای ${escapeHTML(c.name)}" title="${c.repeatNeeded?'لغو انجام دوباره':'دوباره باید انجام شود'}">${icon('i-repeat')}</button>
      </div>
      <button class="menu-btn" data-menu="${c.id}" aria-label="گزینه‌های ${escapeHTML(c.name)}">${icon('i-more')}</button>
    </article>`).join('');

  $$('[data-done]').forEach(box => box.onchange = () => {
    const id = box.dataset.done;
    const previous = contacts.find(c=>c.id===id);
    if(!previous) return;

    if(box.checked && !previous.done){
      const reward = previous.stage ? (STAGES[previous.stage]?.points || 10) : 5;
      const rewardDate = awardGamePoints(reward);
      contacts = contacts.map(c => c.id === id ? {
        ...c, done:true, repeatNeeded:false, currentReward:{points:reward,date:rewardDate}
      } : c);
      save(); render();
      toast(`انجام شد؛ +${fa(reward)} امتیاز`);
      return;
    }

    if(!box.checked && previous.done){
      const fallback = previous.stage ? (STAGES[previous.stage]?.points || 10) : 5;
      const reward = Number(previous.currentReward?.points || fallback);
      const rewardDate = String(previous.currentReward?.date || '');
      deductGamePoints(reward, rewardDate);
      contacts = contacts.map(c => c.id === id ? {
        ...c, done:false, repeatNeeded:false, currentReward:null
      } : c);
      save(); render();
      toast(`تیک برداشته شد؛ −${fa(reward)} امتیاز`);
    }
  });
  $$('[data-repeat]').forEach(btn => btn.onclick = () => toggleRepeatNeeded(btn.dataset.repeat));
  $$('[data-stage-change]').forEach(btn => btn.onclick = () => openStageDialog([btn.dataset.stageChange]));
  $$('[data-menu]').forEach(btn => btn.onclick = () => openActionDialog(btn.dataset.menu));
  $$('[data-call]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.call, 'call'));
  $$('[data-sms]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.sms, 'sms'));
  $$('[data-telegram]').forEach(btn => btn.onclick = () => contactAction(btn.dataset.telegram, 'telegram'));
}

function toggleRepeatNeeded(id){
  const current = contacts.find(c=>c.id===id);
  if(!current) return;
  const nextFlag = !current.repeatNeeded;
  const wasDone = Boolean(current.done);
  contacts = contacts.map(c => c.id !== id ? c : {
    ...c,
    repeatNeeded:nextFlag,
    // «دوباره باید انجام شود» یعنی یک انجام قبلی معتبر می‌ماند، ولی کار جاری دوباره باز می‌شود.
    done:nextFlag && wasDone ? false : c.done,
    currentReward:nextFlag && wasDone ? null : c.currentReward
  });
  save();
  render();
  if(nextFlag && wasDone) toast('برای انجام دوباره باز شد؛ امتیاز قبلی حفظ شد');
  else toast(nextFlag ? 'علامت «دوباره باید انجام شود» فعال شد' : 'علامت انجام دوباره برداشته شد');
}

function renderFilterState(){}
function render(){ renderGamification(); renderStats(); renderContacts(); }

function openContactDialog(id=null){
  const c = contacts.find(x=>x.id===id);
  $('#dialogTitle').textContent = c ? 'ویرایش مخاطب' : 'افزودن مخاطب';
  $('#contactId').value = c?.id || '';
  $('#nameInput').value = c?.name || '';
  $('#phoneInput').value = c?.phone || '';
  $('#stageInput').value = c?.stage || '';
  $('#noteInput').value = c?.note || '';
  openDialog('#contactDialog');
  if (c) setTimeout(()=>$('#nameInput').focus(),50);
}

$('#contactForm').addEventListener('submit', e => {
  e.preventDefault();
  const name=$('#nameInput').value.trim(), phone=$('#phoneInput').value.trim();
  if(!name || !phone){ toast('نام و شماره موبایل را وارد کن'); return; }
  const id=$('#contactId').value;
  const nextStage=$('#stageInput').value;
  const data={name,phone,stage:nextStage,note:$('#noteInput').value.trim()};
  if(id){
    const idx=contacts.findIndex(c=>c.id===id);
    if(idx>=0){
      const stageChanged = contacts[idx].stage !== nextStage;
      contacts[idx]={
        ...contacts[idx],
        ...data,
        done:stageChanged ? false : Boolean(contacts[idx].done),
        repeatNeeded:stageChanged ? false : Boolean(contacts[idx].repeatNeeded),
        // تغییر مرحله امتیاز قبلی را پس نمی‌گیرد؛ فقط تیک مرحله جدید از نو شروع می‌شود.
        currentReward:stageChanged ? null : contacts[idx].currentReward
      };
    }
    toast('مخاطب ویرایش شد');
  } else {
    contacts.unshift({id:makeId(),createdAt:Date.now(),done:false,repeatNeeded:false,currentReward:null,rewardedStages:[],...data});
    toast('مخاطب به لیست مرجع اضافه شد');
  }
  save(); closeDialog('#contactDialog'); render();
});

function openStageDialog(ids){
  stageTargetIds = ids;
  const options = Object.entries(STAGES).map(([key,v])=>`
    <button type="button" class="stage-option" data-stage-option="${key}"><span>${icon(v.icon)} ${v.label}</span>${icon('i-chevron')}</button>`).join('');
  $('#stageOptions').innerHTML = options + `
    <button type="button" class="stage-option remove-stage" data-stage-option=""><span>${icon('i-users')} فقط در لیست مرجع</span>${icon('i-chevron')}</button>`;
  $$('[data-stage-option]').forEach(btn => btn.onclick = () => {
    const newStage = btn.dataset.stageOption;
    let changed = false;
    contacts = contacts.map(c => {
      if(!stageTargetIds.includes(c.id)) return c;
      if(c.stage === newStage) return c;
      changed = true;
      return {
        ...c, stage:newStage, done:false, repeatNeeded:false, currentReward:null
      };
    });
    save(); closeDialog('#stageDialog'); render();
    if(changed){
      toast(newStage ? 'مرحله تغییر کرد؛ تیک ریست شد و امتیاز قبلی حفظ شد' : 'به لیست مرجع منتقل شد؛ امتیاز قبلی حفظ شد');
    }else toast('مرحله تغییری نکرد');
  });
  openDialog('#stageDialog');
}

function openActionDialog(id){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  actionTargetId=id;
  $('#actionContactName').textContent=c.name;
  const repeatLabel = $('#repeatContactAction span');
  if(repeatLabel) repeatLabel.textContent = c.repeatNeeded ? 'لغو انجام دوباره' : 'دوباره باید انجام شود';
  openDialog('#actionDialog');
}

$('#editContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openContactDialog(id); };
$('#moveContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); openStageDialog([id]); };
$('#repeatContactAction').onclick=()=>{ const id=actionTargetId; closeDialog('#actionDialog'); toggleRepeatNeeded(id); };
$('#deleteContactAction').onclick=()=>{
  const c=contacts.find(x=>x.id===actionTargetId); if(!c) return;
  if(confirm(`«${c.name}» از لیست حذف شود؟`)){
    contacts=contacts.filter(x=>x.id!==c.id); save(); closeDialog('#actionDialog'); render(); toast('مخاطب حذف شد');
  }
};
$('#callContactAction').onclick=()=>contactAction(actionTargetId,'call');
$('#smsContactAction').onclick=()=>contactAction(actionTargetId,'sms');
$('#telegramContactAction').onclick=()=>contactAction(actionTargetId,'telegram');

function normalizedPhone(value=''){
  return String(value).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9+]/g,'');
}
function telegramPhone(value=''){
  let p = normalizedPhone(value);
  if (p.startsWith('00')) p = '+' + p.slice(2);
  if (p.startsWith('0') && p.length >= 10) p = '+98' + p.slice(1);
  else if (p.startsWith('98') && !p.startsWith('+')) p = '+' + p;
  return p;
}
function androidBridgeMethod(name){
  return window.AndroidContacts && typeof window.AndroidContacts[name] === 'function';
}
function contactAction(id, type){
  const c=contacts.find(x=>x.id===id); if(!c) return;
  const phone=c.phone;
  try{
    if(type==='call'){
      if(androidBridgeMethod('openDialer')) window.AndroidContacts.openDialer(phone);
      else window.location.href=`tel:${normalizedPhone(phone)}`;
    } else if(type==='sms'){
      if(androidBridgeMethod('openSms')) window.AndroidContacts.openSms(phone);
      else window.location.href=`sms:${normalizedPhone(phone)}`;
    } else if(type==='telegram'){
      if(androidBridgeMethod('openTelegram')) window.AndroidContacts.openTelegram(phone);
      else window.location.href=`tg://resolve?phone=${encodeURIComponent(telegramPhone(phone))}`;
    }
  }catch(e){ toast('باز کردن برنامه مربوطه ممکن نشد'); }
}
window.receiveExternalActionError = function(message){ toast(message || 'باز کردن برنامه مربوطه ممکن نشد'); };

function pickContactFromPhone(){
  if(androidBridgeMethod('pickContact')){
    window.AndroidContacts.pickContact();
  }else{
    toast('در نسخه وب، فایل CSV یا VCF مخاطبین را انتخاب کن');
    $('#contactFile').click();
  }
}
window.receiveAndroidPickedContact = function(payload){
  try{
    const c = typeof payload === 'string' ? JSON.parse(payload) : payload;
    if(!c?.phone){ toast('برای این مخاطب شماره تلفن پیدا نشد'); return; }
    if(!$('#contactDialog').open) openContactDialog();
    $('#nameInput').value = c.name || 'بدون نام';
    $('#phoneInput').value = c.phone || '';
    setTimeout(()=>$('#stageInput').focus(),100);
    toast('مخاطب انتخاب شد؛ مرحله را مشخص کن و ذخیره کن');
  }catch(e){ toast('خواندن مخاطب انتخاب‌شده با خطا روبه‌رو شد'); }
};
window.receiveAndroidContactsError = function(message){ toast(message || 'دسترسی به مخاطبین ممکن نیست'); };

function parseCSVLine(line){
  const out=[]; let cur='', q=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch==='"' && line[i+1]==='"' && q){cur+='"';i++;}
    else if(ch==='"')q=!q;
    else if(ch===',' && !q){out.push(cur);cur='';}
    else cur+=ch;
  }
  out.push(cur); return out;
}
async function importContactFile(file){
  if(!file) return;
  const text=await file.text(); let added=0;
  if(file.name.toLowerCase().endsWith('.csv') || file.type.includes('csv')){
    const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean);
    const start = /نام|name/i.test(lines[0]||'') ? 1 : 0;
    for(let i=start;i<lines.length;i++){
      const [name,phone,,note] = parseCSVLine(lines[i]);
      if(name?.trim() && phone?.trim()){
        contacts.unshift({id:makeId(),name:name.trim(),phone:phone.trim(),stage:'',note:(note||'').trim(),done:false,repeatNeeded:false,currentReward:null,rewardedStages:[],createdAt:Date.now()+added});
        added++;
      }
    }
  }else{
    const cards=text.split(/END:VCARD/i);
    for(const card of cards){
      const name=(card.match(/\nFN(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      const phone=(card.match(/\nTEL(?:;[^:]*)?:(.+)/i)||[])[1]?.trim();
      if(name&&phone){contacts.unshift({id:makeId(),name,phone,stage:'',note:'از فایل مخاطبین',done:false,repeatNeeded:false,currentReward:null,rewardedStages:[],createdAt:Date.now()+added});added++;}
    }
  }
  if(added){save();render();toast(`${fa(added)} مخاطب اضافه شد`);} else toast('مخاطبی از فایل پیدا نشد');
}

function exportCSV(){
  const rows=[['نام','شماره','مرحله','انجام شده','یادداشت'],...contacts.map(c=>[c.name,c.phone,c.stage?STAGES[c.stage]?.label||'':'',c.done?'بله':'خیر',c.note||''])];
  const csv='\uFEFF'+rows.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='contacts.csv'; a.click(); setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('خروجی CSV ساخته شد');
}

$('#addBtn').onclick=()=>openContactDialog();
$('#importBtn').onclick=()=>{ openContactDialog(); pickContactFromPhone(); };
$('#pickPhoneContactBtn').onclick=pickContactFromPhone;
$('#menuBtn').onclick=()=>openDialog('#menuDialog');
$('#pickContactMenuBtn').onclick=()=>{ closeDialog('#menuDialog'); openContactDialog(); setTimeout(pickContactFromPhone,120); };
$('#fileImportBtn').onclick=()=>{ closeDialog('#menuDialog'); $('#contactFile').click(); };
$('#contactFile').onchange=e=>{ importContactFile(e.target.files?.[0]); e.target.value=''; };
$('#exportBtn').onclick=()=>{exportCSV();closeDialog('#menuDialog')};
$('#clearBtn').onclick=()=>{
  if(confirm('همه مخاطبین و اطلاعات ذخیره‌شده پاک شوند؟')){
    contacts=[];
    game={totalXp:0,todayPoints:0,streak:0,todayCompletions:0,todayDate:dayKey(),lastActivityDate:''};
    save();saveGame();closeDialog('#menuDialog');render();toast('همه داده‌ها و پیشرفت پاک شد');
  }
};


$$('[data-close]').forEach(btn=>btn.onclick=()=>closeDialog(`#${btn.dataset.close}`));
$$('dialog').forEach(d=>d.addEventListener('click',e=>{ if(e.target===d) d.close(); }));


const DAILY_TIPS = [
  {title:'اول اقدام، بعد نتیجه', text:'امروز روی انجام یک اقدام ساده تمرکز کن؛ یک تماس خوب از ده بار فکر کردن ارزشمندتر است.'},
  {title:'یادداشت کوتاه بگذار', text:'بعد از تماس، یک جمله درباره نتیجه بنویس تا فالوآپ بعدی دقیق‌تر و شخصی‌تر باشد.'},
  {title:'مرحله را سریع جلو ببر', text:'وقتی کار یک مرحله انجام شد تیک بزن؛ اگر مخاطب آماده بود به مرحله بعد منتقلش کن تا تیک جدید از صفر شروع شود.'},
  {title:'از افراد گرم شروع کن', text:'مخاطب‌هایی که اخیراً پاسخ داده‌اند یا یادداشت مشخص دارند، معمولاً بهترین نقطه برای شروع امروز هستند.'},
];
let tipIndex = Number(localStorage.getItem('networkCRM.tipIndex') || 0) % DAILY_TIPS.length;
function renderTip(){
  const tip = DAILY_TIPS[tipIndex] || DAILY_TIPS[0];
  $('#tipTitle').textContent = tip.title;
  $('#tipText').textContent = tip.text;
}
function openTips(){ renderTip(); openDialog('#tipsDialog'); }
function openReport(){
  const done = contacts.filter(c=>c.done).length;
  const completion = contacts.length ? Math.round(done / contacts.length * 100) : 0;
  const totalXp = Math.max(0, Number(game.totalXp||0));
  const level = Math.floor(totalXp / XP_PER_LEVEL) + 1;
  $('#reportGrid').innerHTML = `
    <div class="report-kpi"><span>کل مخاطبین</span><strong>${fa(contacts.length)}</strong></div>
    <div class="report-kpi"><span>کارهای تیک‌خورده</span><strong>${fa(done)}</strong></div>
    <div class="report-kpi"><span>نرخ انجام</span><strong>${fa(completion)}٪</strong></div>
    <div class="report-kpi"><span>سطح فعلی</span><strong>${fa(level)}</strong></div>`;
  const maxCount = Math.max(1, ...Object.keys(STAGES).map(k=>contacts.filter(c=>c.stage===k).length));
  $('#reportStageList').innerHTML = Object.entries(STAGES).map(([key,s])=>{
    const n=contacts.filter(c=>c.stage===key).length;
    const width=Math.round(n/maxCount*100);
    return `<div class="report-stage"><strong>${escapeHTML(s.label)}</strong><div class="report-bar"><i style="width:${width}%"></i></div><span>${fa(n)}</span></div>`;
  }).join('');
  $('#reportMessage').textContent = completion >= 70 ? 'ریتمت عالی است؛ همین پیوستگی را حفظ کن.' : completion >= 35 ? 'پیشرفت خوب است؛ چند اقدام کوچک دیگر امروز نتیجه را بهتر می‌کند.' : 'از یک مخاطب شروع کن؛ هر تیک یک قدم واقعی در مسیر پیشرفت است.';
  openDialog('#reportDialog');
}
$('#bottomAddBtn').onclick=()=>openContactDialog();
if($('#tipsBtn')) $('#tipsBtn').onclick=openTips;
if($('#reportBtn')) $('#reportBtn').onclick=openReport;
if($('#nextTipBtn')) $('#nextTipBtn').onclick=()=>{ tipIndex=(tipIndex+1)%DAILY_TIPS.length; localStorage.setItem('networkCRM.tipIndex', String(tipIndex)); renderTip(); };

// توسط دکمه Back اندروید صدا زده می‌شود. یک بار، کاربر را به نمای اصلی «همه» برمی‌گرداند.
window.handleAndroidBack = function(){
  let changed = false;
  $$('dialog').forEach(d=>{ if(d.open){ d.close(); changed = true; } });
  if(activeStage !== 'all'){
    activeStage = 'all';
    changed = true;
  }
  if(changed){
    render();
    window.scrollTo({top:0,behavior:'smooth'});
  }
  return changed;
};



function applyIntegratedTheme(theme){document.documentElement.classList.toggle('theme-light',theme==='light');document.documentElement.style.colorScheme=theme==='light'?'light':'dark'}
function importIntegratedState(payload){try{if(!payload||typeof payload!=='object')return;if(Array.isArray(payload.contacts)){contacts=payload.contacts.map(normalizeContact);localStorage.setItem(storageKey,JSON.stringify(contacts))}if(payload.game&&typeof payload.game==='object'){game={...defaultGame(),...payload.game};normalizeGameDay();localStorage.setItem(gameStorageKey,JSON.stringify(game))}render();emitIntegratedState()}catch(_){}}
function syncTreePeople(treePeople){try{if(!Array.isArray(treePeople))return;let changed=false;treePeople.forEach(p=>{if(!p||!p.name)return;let hit=contacts.find(c=>Number(c.treePersonId||0)===Number(p.id))||contacts.find(c=>String(c.name||'').trim()===String(p.name||'').trim());if(hit){if(!hit.treePersonId){hit.treePersonId=p.id;changed=true}if(String(hit.name||'')!==String(p.name||'')){hit.name=String(p.name||'');changed=true}return}contacts.push(normalizeContact({id:makeId(),treePersonId:p.id,name:String(p.name),phone:'',stage:'',note:'',done:false,repeatNeeded:false,currentReward:null,rewardedStages:[],createdAt:Date.now()+contacts.length}));changed=true});if(changed){localStorage.setItem(storageKey,JSON.stringify(contacts));render();emitIntegratedState()}}catch(_){}}
window.addEventListener('message',e=>{try{let d=e.data||{};if(d.type==='gamification-theme')applyIntegratedTheme(d.theme);if(d.type==='list-import')importIntegratedState(d.payload);if(d.type==='list-tree-people')syncTreePeople(d.people)}catch(_){}});
const integratedBackBtn=document.getElementById('integratedBackBtn');if(integratedBackBtn)integratedBackBtn.onclick=()=>{try{parent.postMessage({type:'list-close'},'*')}catch(_){}};
try{window.top.postMessage({type:'list-ready'},'*')}catch(_){}


// v2.39 integrated four-label workflow
let integratedOwner=null,integratedTreePeople=[];
function integratedDateLabel(ts=Date.now()){try{return new Date(ts).toLocaleDateString('fa-IR')}catch(_){return ''}}
function integratedActionLabel(key){return STAGES[key]?.label||String(key||'اقدام')}
function integratedActions(){const out=[];contacts.forEach(c=>(Array.isArray(c.actions)?c.actions:[]).forEach(a=>out.push({contact:c,action:a})));return out.sort((a,b)=>Number(b.action.at||0)-Number(a.action.at||0))}
function openIntegratedTab(name){document.querySelectorAll('.integrated-tab').forEach(b=>b.classList.toggle('active',b.dataset.integratedTab===name));document.querySelectorAll('.integrated-pane').forEach(p=>p.classList.toggle('active',p.id===`integrated-${name}`));if(name==='summary')renderIntegratedSummary();if(name==='people')renderIntegratedPeople();if(name==='team')renderIntegratedTeam();if(name==='register')setTimeout(()=>document.getElementById('integratedProspectName')?.focus(),60)}
document.querySelectorAll('.integrated-tab').forEach(b=>b.onclick=()=>openIntegratedTab(b.dataset.integratedTab));
function actionDetailsHTML(result){return escapeHTML(String(result||'بدون توضیح'))}
function renderIntegratedSummary(){const host=document.getElementById('integratedSummaryList');if(!host)return;const rows=integratedActions();host.innerHTML=rows.length?rows.map(({contact:c,action:a})=>`<details class=\"integrated-entry\"><summary><div><div class=\"entry-name\">${escapeHTML(c.name)}</div><div class=\"entry-meta\">${escapeHTML(a.date||integratedDateLabel(a.at))}</div></div><div class=\"entry-action\">${escapeHTML(integratedActionLabel(a.type))}</div><span class=\"entry-arrow\">⌄</span></summary><div class=\"entry-detail\">${actionDetailsHTML(a.result)}</div></details>`).join(''):'<div class=\"integrated-empty\">هنوز اقدامی ثبت نشده است.</div>'}
function renderIntegratedPeople(){const host=document.getElementById('integratedPeopleList');if(!host)return;const rows=contacts.filter(c=>!c.treePersonId&&(!Array.isArray(c.actions)||c.actions.length===0));host.innerHTML=rows.length?rows.sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0)).map(c=>`<div class=\"simple-person\">${escapeHTML(c.name)}</div>`).join(''):'<div class=\"integrated-empty\">فرد بدون اقدام وجود ندارد.</div>'}
function teamFeedRows(){const rows=[],seen=new Set();integratedTreePeople.forEach(p=>(Array.isArray(p.network)?p.network:[]).forEach(a=>{const key=`${p.id}|${a.name}|${a.type}|${a.date}`;if(seen.has(key))return;seen.add(key);rows.push({prospect:String(a.name||''),referrer:String(p.name||''),date:String(a.date||''),type:String(a.type||'اقدام'),result:String(a.result||''),at:Number(a.id||0)})}));integratedActions().forEach(({contact:c,action:a})=>{const rid=Number(a.referrerTreePersonId||c.referrerTreePersonId||0);if(!rid)return;const ref=String(a.referrerName||c.referrerName||integratedTreePeople.find(p=>Number(p.id)===rid)?.name||'');const key=`${rid}|${c.name}|${integratedActionLabel(a.type)}|${a.date||''}`;if(seen.has(key))return;seen.add(key);rows.push({prospect:c.name,referrer:ref,date:a.date||integratedDateLabel(a.at),type:integratedActionLabel(a.type),result:a.result||'',at:Number(a.at||0)})});return rows.sort((a,b)=>Number(b.at||0)-Number(a.at||0))}
function renderIntegratedTeam(){const host=document.getElementById('integratedTeamList');if(!host)return;const rows=teamFeedRows();host.innerHTML=rows.length?rows.map(r=>`<details class=\"integrated-entry\"><summary><div><div class=\"entry-name\">${escapeHTML(r.prospect)}</div><div class=\"entry-meta\">معرف: ${escapeHTML(r.referrer||'—')} • ${escapeHTML(r.date||'')}</div></div><div class=\"entry-action\">${escapeHTML(r.type)}</div><span class=\"entry-arrow\">⌄</span></summary><div class=\"entry-detail\">${actionDetailsHTML(r.result)}</div></details>`).join(''):'<div class=\"integrated-empty\">هنوز اقدامی از شبکه تیم ثبت نشده است.</div>'}
const integratedProspectForm=document.getElementById('integratedProspectForm');if(integratedProspectForm)integratedProspectForm.addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('integratedProspectName').value.trim(),type=document.getElementById('integratedActionType').value,result=document.getElementById('integratedActionResult').value.trim();if(!name||!result){toast('اسم پراسپکت و نتیجه را وارد کن');return}let c=contacts.find(x=>!x.treePersonId&&String(x.name||'').trim()===name);if(!c){c=normalizeContact({id:makeId(),name,phone:'',stage:type,note:result,done:false,createdAt:Date.now(),actions:[],referrerTreePersonId:integratedOwner?.id||null,referrerName:integratedOwner?.name||''});contacts.unshift(c)}const at=Date.now(),action={id:at,type,result,at,date:integratedDateLabel(at),referrerTreePersonId:integratedOwner?.id||c.referrerTreePersonId||null,referrerName:integratedOwner?.name||c.referrerName||''};c.stage=type;c.note=result;c.referrerTreePersonId=action.referrerTreePersonId;c.referrerName=action.referrerName;c.actions=Array.isArray(c.actions)?c.actions:[];c.actions.unshift(action);save();try{parent.postMessage({type:'list-tree-action',ownerId:action.referrerTreePersonId,action:{...action,typeLabel:integratedActionLabel(type),prospectName:name}},'*')}catch(_){}document.getElementById('integratedProspectName').value='';document.getElementById('integratedActionResult').value='';toast('ثبت شد');renderIntegratedSummary();renderIntegratedTeam();setTimeout(()=>document.getElementById('integratedProspectName').focus(),60)});
const integratedPersonQuickForm=document.getElementById('integratedPersonQuickForm');if(integratedPersonQuickForm)integratedPersonQuickForm.addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('integratedPersonName'),name=input.value.trim();if(!name)return;const exists=contacts.some(c=>!c.treePersonId&&String(c.name||'').trim()===name);if(!exists){contacts.unshift(normalizeContact({id:makeId(),name,phone:'',stage:'',note:'',done:false,createdAt:Date.now(),actions:[],referrerTreePersonId:integratedOwner?.id||null,referrerName:integratedOwner?.name||''}));save();toast('ثبت شد')}else toast('این اسم قبلاً ثبت شده');input.value='';renderIntegratedPeople();setTimeout(()=>input.focus(),30)});
function applyListContext(d){integratedOwner=d&&d.owner?{id:Number(d.owner.id),name:String(d.owner.name||'')}:null;integratedTreePeople=Array.isArray(d&&d.people)?d.people:integratedTreePeople;openIntegratedTab('register')}
window.addEventListener('message',e=>{try{const d=e.data||{};if(d.type==='list-context')applyListContext(d);if(d.type==='list-tree-people'){integratedTreePeople=Array.isArray(d.people)?d.people:[];renderIntegratedTeam()}}catch(_){}});

render();
