# Billionaires Action — v2.52.0 (rebased on v2.19)

نسخه ۱۹ با Quest Deck، Rank مبتنی بر R، XP، Combo یک‌ساعته، Focus 25 دقیقه‌ای ×2، صندوق‌های جایزه، دستاوردها، تنظیمات، Backup، Day/Night و Game Audio.

## صندوق
- روزانه: 4 / 7 / 10 / 15 / 20 اقدام
- هفتگی: 20 / 35 / 50 / 75 / 100 اقدام
- ماهانه: 80 / 150 / 250 / 400 / 600 اقدام
- صندوق آماده را لمس کن تا XP آن دریافت شود.

## روز بازی
روز به‌صورت پیش‌فرض ساعت 06:00 شروع می‌شود. تا قبل از 06:00، تسک‌های روز قبل همچنان فعال هستند. ساعت شروع روز از تنظیمات قابل تغییر است.

## Combo
- 0 تا 4 اقدام: ×1
- 5 تا 9: ×2
- 10 تا 14: ×3
- 15 تا 19: ×4
- 20 به بالا: ×5
- هر اقدام موفق پنجره Combo را یک ساعت تمدید می‌کند.
- حذف تسک یا پایان یک ساعت: Combo = 0.

## Rank
فقط تسک‌های R پیشرفت Rank می‌دهند.

## Focus
تا زمانی که تایمر 25 دقیقه‌ای فعال است، امتیاز همه تسک‌ها ×2 می‌شود.


## v2.20 rebase note
This release returns to the v2.19 feature baseline and only adds the compact Settings/audio changes documented in `UPDATE-20.md`.


## v2.21 HUD + Focus
- HUD labels: Done!, Rank, XP, Combo.
- Done! shows actions completed in the current game day.
- Focus timer uses English digits and icon-only start/stop controls.


## v2.22
Mission HUD cleanup on the v19 rebase: English combo timer/counter, compact multiplier display, and simplified mission metadata.


## v2.23
- Combo multipliers: 2 actions = ×2, 5 = ×3, 8 = ×4, 12 = ×5.
- Combo window is 30 minutes and extends after each completed task.
- Larger English combo timer with tiered animated flame.
- Android notification 2 minutes before combo expiry.


## v2.24
- Combo is now a campfire: x2 uses 2 logs, x3 uses 3, x4 uses 4, and x5 uses 5, with stronger flames by tier.
- Card swiping is faster and lighter with shorter transitions and no blur-heavy swap flash.
- Return-to-first-task button is redesigned as a compact neon arrow.
- Focus shows `Focus` while idle and switches to the English countdown only after start.


## v2.25 — Fire Timer + HUD Stats
- Combo timer no longer contains wood/log graphics; the full timer pill becomes an animated flame surface once combo ×2 is active.
- Flame intensity scales with combo tier (×2 to ×5).
- Tapping Done!, Rank, XP, or Combo opens a dedicated animated statistics panel for that metric.
- Existing v19-based game logic, 30-minute combo, focus, vaults, achievements, settings, and backup remain intact.


## v2.26 — TimeSheet Integrated
- TimeSheet v7 core workflow is integrated as a native page inside the gamification WebView.
- Navigation order: Game, Tasks, Vault, TimeSheet, Achievements, Settings.
- Weekly navigation supports ±10 weeks, Saturday-Friday rows, 07:00-24:00 slots, event creation/edit/delete/status, recurring weekly events, compact weekly overview, Jalali dates, and persistent storage.
- TimeSheet is visually rebuilt with the current gamification dark/light neon theme.
- TimeSheet data is stored inside the gamification state, so it participates in the existing export/import backup.


## v2.27 — TimeSheet Zoom + Reminder
- Added TimeSheet zoom in/out controls (70%–150%).
- Week header now shows only relative text: this week / N weeks before / N weeks after.
- Added icon-only return-to-current-week control when browsing another week.
- Removed TimeSheet week-overview option.
- Added optional 5-minute-before program notifications; reminders are OFF by default and activate only when checked per program.
- Recurring enabled reminders continue weekly; editing/deleting/status changes reschedule or cancel the alarm appropriately.

## v2.28 — Pinch Zoom + Light Contrast + HD Focus Audio
- TimeSheet subtitle "برنامه هفتگی" removed.
- TimeSheet zoom buttons removed; two-finger pinch zoom now controls the board from 50% to 150% and saves the zoom level.
- Settings heading changed to English `Settings` with the gear on the left.
- Light theme received a broad contrast/readability pass across HUD, mission card, task list, vault, achievements, settings, navigation, modals, and TimeSheet.
- Focus sound labels simplified: موج دریا، پیانو، جنگل، صدای آدم‌ها.
- All 10 focus ambience tracks regenerated as 48 kHz stereo 30-second loops at higher quality; piano is a newly synthesized Bach-inspired/public-domain Prelude in C major focus arrangement.


## v2.29 — Rewards Hub + Derakhtvare v21
- صندوق and دستاوردها are merged into one redesigned **پاداش‌ها** page with an internal two-tab switch.
- Bottom navigation stays at six items by replacing the separate achievements tab with a new **درختواره** tab.
- Added an integrated Derakhtvare v21 surface using the original v21 data model and tools, visually restyled to match Gamification.
- The Derakhtvare page includes four selectable modes: **PV / GPV**, **درختواره**, **مقایسه**, and **رنکینگ**.
- Tree add/edit member flows, PV/GPV entry, active-count data, circular hierarchy, tree zoom, person/time comparisons, ranking modes, and network-action data from v21 remain available.
- Dark/light theme is synchronized from Gamification into the embedded tree surface.
- Tree data is mirrored into the Gamification backup state so exported backups can carry the integrated tree data too.


## v2.30 — Clean Tree Hub + Pan/Zoom
- Removed the large Tree Hub title/version strip from Gamification.
- Removed the embedded page-title/header strip from the Tree app while keeping the four mode selectors.
- Expand-all and collapse-all are now icon-only controls.
- Tree view supports zoom in/out from 20% to 180%, two-finger pinch zoom, and one-finger free panning across both axes.
- Tree controls and pan surface are synchronized with Gamification dark/light themes.


## v2.31 — Card-first gameplay
- Removed the standalone Tasks page and its navigation item.
- Card title on the Game screen opens a per-card 30-day activity view.
- Card statistics show the last 30 days, current scheduled streak, and total completion count.
- A top-right three-dot menu on card statistics provides Edit Card, New Card, and permanent Delete Card.
- Card editor now contains only card name, short description, base points, and weekday recurrence.
- Game modes, labels, and default enabled/disabled status were removed.
- Rank cards are now automatic: any card with 30 or more base points contributes to Rank.
- Weekday recurrence controls which days a card appears in the Game deck.
- Return-to-first-card control was redesigned around the ⏪️ icon.


## v2.32 — PV / GPV Clean Layout
- Removed the per-person position counter from PV / GPV cards.
- Removed the swipe instruction under the cards.
- Simplified fields to `PV :`, `GPV :`, and `تعداد :` with the numeric value beside each label.
- Expanded the embedded PV / GPV workspace to use the full available height and eliminated unnecessary vertical page scrolling.

## v2.33 — Dream Board v20 Hub
- Removed the Rewards page and all Achievements / Vault / Chest UI and active reward-system hooks.
- Added a new main navigation page: `تابلورویا`.
- Added a self-contained Dream Board hub styled to match Gamification, following the same integration pattern as Derakhtvare.
- Dream Board hub sections: تابلو رویاها، اکسپلور، دارایی، آمار.
- Added year boards, dream items, completion tracking, values, categories, notes, photo upload, year/dream edit/delete, gallery filtering, asset tracking, one-million-dollar progress, and yearly statistics.
- Dream Board theme is synchronized with Gamification light/dark mode.
- Dream Board data is synchronized into the Gamification backup/import envelope.
- Android WebView image file chooser added for dream-photo selection.

## v2.34 — Single-Year Dream Carousel
- The Dream Board now shows one selected year at a time instead of all years together.
- Arrow controls move to the previous/next year and the selection is saved.
- Dreams for that year are presented as full-area, one-at-a-time image slides with horizontal swipe/scroll and snap behavior.
- Each dream shows its title and price directly over the lower part of the image.
- Compact edit and completion controls remain available on each dream.
- The final slide adds a new dream; year add/edit controls remain in the year header.

## v2.35 — Dream Board Editor + Crop
- Year numbers are shown without thousands separators (for example: ۱۴۰۵).
- Tapping the year itself opens year edit controls; the separate three-dot year button was removed.
- On the final year, the next-year arrow becomes a + button to add a new year.
- Removed the year short-title field and reduced the year navigation bar height.
- Dream add/edit UI was enlarged for readability.
- Dream form now focuses on title, target value, photo, Crop, and completion state.
- Removed dream description and dream category controls; Explore no longer has category filters or category labels.
- Native file text is hidden behind a clear «انتخاب عکس» gallery button with a neighboring «حذف عکس» button.
- Selected photos are not previewed in the editor; saved changes appear on the dream board.
- Added a working Crop workspace with one-finger repositioning and zoom control before applying the crop.


## v2.36 — Dreamboard Minimal High-Resolution Crop
- Dream editor photo row simplified to Select Photo / icon-only Crop / Remove Photo.
- Removed photo labels, Crop section text, and the editor achieved checkbox.
- Goal completion is now an icon-only hollow circle at the top-right of each dream; tapping toggles it to a check mark.
- Year label is larger.
- Crop workspace keeps only the `Crop` title and icon-only Cancel / Reset / Apply controls.
- Removed zoom slider and crop instructions.
- Crop uses one-finger pan and two-finger pinch zoom.
- Selected images are no longer pre-downscaled; crop output uses the selected source-pixel region at its native crop dimensions.


## v2.37 — Daily Tree Entry + TimeSheet Pan
- Daily PV/GPV/count entry with day rollover and save-to-next-person workflow.
- One-finger full TimeSheet pan after zoom; two-finger pinch retained.
- Smaller dream image edit and achieved controls.

## v2.40 — Scoped People & Actions
- Three-step Android Back flow: section root → Game → exit/background.
- Bottom navigation always opens the root of the selected section.
- Tree gesture hint removed; PV/GPV cards now keep equal opacity for all people.
- People/Actions and Add Direct buttons are larger and visually matched.
- Each tree member has an isolated People & Actions workspace.
- Summary shows only that member's own actions; people list is owner-specific and deletable.
- Team networking feed includes only descendants in that member's subtree, excluding self and outsiders.


## v2.41 — Full Backup + Editable People/Actions
- Full-app Export/Import now captures game state, cards/statistics/settings, TimeSheet, Dream Board, the complete Tree hierarchy/daily archive/compare state/zoom, and the integrated People & Actions list.
- Backup payload avoids duplicating the large embedded modules while preserving backward-compatible top-level sections.
- Tree daily-entry state and UI hierarchy state are restored with imports.
- First Android Back closes open windows and returns the current section to its section root; nested People & Actions dialogs are also reset.
- Action Summary entries can be edited (prospect, action type, result, date) and changes sync back to the matching Tree networking action.
- People List entries can be renamed; delete remains available.
- Action Summary and People List received a stronger gamified card design in both dark and light themes.

## v2.42 — PV/GPV Daily Carry + History Import
- Daily PV / GPV values carry forward per person instead of resetting to zero.
- Historical Tree snapshots are exported/imported explicitly and redundantly for safer recovery.
- Imported history stays available for date comparison, and today's snapshot is generated without deleting older dates.

## v2.43 — Person Goals + To Do + Circular Tree Cleanup
- Three-dot goal/settings menu beside each PV/GPV person name.
- Per-person PV, GPV, and count goals.
- Per-person To Do List with completion sorting and delete.
- Equal-size circular tree nodes with larger metrics and no add/menu controls.


## v2.44 — Comparison Redesign
- Compact compare tabs; temporal comparison is default.
- Dedicated year/month/day archive date picker.
- Person and three dates stay on one row.
- Comparison metrics limited to PV, GPV, and active people.


## v2.45 — Dream Priority & Explore
- Ranking subtitle removed.
- Completed dreams sort to the end of each year.
- Dream priority can be moved up/down from the three-dot menu.
- Explore supports yearless photo goals, random full-screen vertical browsing, and title/right + price/left overlays.


## v2.46 — Assets + Dream Storage Pressure
- Asset total includes achieved dreams plus manual assets.
- Three next priority goals are shown.
- Stats UI was removed.
- Dream/Explore imports were compressed to reduce LocalStorage pressure.

## v2.47 — IndexedDB Dream Media
- Dream/Explore images are stored as Blobs in IndexedDB; state keeps only lightweight image references.
- Existing embedded Base64 photos migrate automatically.
- Full backup/restore preserves IndexedDB images through a temporary backup image archive.
- Explore photos are hydrated lazily to reduce memory pressure.
- Hidden Stats/million-dollar legacy code and several unreachable helpers were removed.
- Internal and Android version metadata are aligned at 2.52.0.


## v2.48 architecture cleanup

The main page has been modularized, Tree daily history is canonicalized, persistent parent iframe-state duplication has been removed, Dreamboard legacy CSS was cleaned up, and historical release notes now live under `docs/history/`.


## v2.50 Settings redesign
- Settings rebuilt as four compact groups: Game, Focus, Display, Data.
- Removed redundant visual controls and explicit save button; settings save immediately.
- Added real animation toggle propagated to Tree, List and Dreamboard.
- Added IndexedDB image storage usage summary and orphan-image cleanup.
- App and backup version metadata aligned at 2.52.0.


## v2.50
- انتخاب صدای پومودورو در صفحه مستقل انجام می‌شود.
- تصاویر جدید Dreamboard/Explore با Android Storage Access Framework از گالری انتخاب می‌شوند و فقط URI پایدار آن‌ها در state ذخیره می‌شود؛ تصویر داخل اپ کپی نمی‌شود.
- Crop برای تصاویر گالری غیرتخریبی است و فقط زوم/موقعیت ذخیره می‌شود.
- بکاپ جدید آدرس تصاویر گالری را ذخیره می‌کند و دیگر برای تصاویر جدید فایل تصویری را داخل JSON قرار نمی‌دهد.
- تصاویر قدیمی IndexedDB برای سازگاری نسخه‌های قبلی همچنان قابل نمایش و بازیابی هستند.


## v2.51 — Gallery display & crop fix
- Fixed Android gallery image delivery from the native picker to Dreamboard/Explore.
- Added an internal read-only WebView media stream for persisted `content://` URIs. Images are read from the gallery on demand and are not copied into app storage.
- Crop now works on gallery images while continuing to store only crop metadata.
- Strengthened persistable URI permission handling.


## v2.52
- Fixed cropped Dreamboard/Explore images not being displayed after Crop.
- Crop display now renders an exact transient 3:4 preview from the original gallery URI using the saved zoom/pan values.
- No permanent image copy is created; cropped previews exist only in memory while the app is open.
- Added cropped-image preview inside Dream/Explore editors immediately after applying Crop.
