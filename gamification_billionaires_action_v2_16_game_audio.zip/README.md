# Billionaires Action — Gamification v2.16

نسخه 2.16 سیستم صوتی بازی را از یک مجموعه افکت ساده به یک **Game Audio System** کامل ارتقا می‌دهد.

## امکانات اصلی بازی
- Quest Deck با Swipe چپ/راست، Combo و انیمیشن‌های گیمی
- تایمر تمرکز ۲۵ دقیقه‌ای با ادامه در پس‌زمینه
- Level / Rank / Magic Focus / Magic Boost
- مدیریت کامل تسک‌ها
- آمار روزانه و هفتگی
- Achievement Hub با پاداش قابل دریافت
- نقطه قرمز برای دستاوردهای دریافت‌نشده
- Backup / Restore
- حالت روز و شب
- رفتار Back: یک بار بازگشت به بازی، دو بار رفتن اپ به پس‌زمینه
- آیکون Billionaires Action

## جدید در v2.16 — Game Audio
- افکت صوتی اختصاصی برای صفحه بازی، تسک‌ها، آمار، دستاوردها و تنظیمات
- صدای جدا برای Swipe، انجام تسک، Combo، حذف، شروع/قطع تمرکز، Level Up، Rank Up، Magic Up، Achievement و Backup
- چهار صدای تکرارشونده برای تمرکز ۲۵ دقیقه‌ای:
  - Flow — آرام و سینمایی
  - Pulse — ریتمیک و انگیزه‌بخش
  - Rain — محیطی و نرم
  - Arcade — گیمی و انرژی‌بخش
- تنظیم شدت صدای Focus از داخل Settings
- تغییر Focus Sound حتی وسط جلسه بدون ریست شدن تایمر
- Focus Audio به‌صورت Foreground Media Service اجرا می‌شود تا در پس‌زمینه ادامه پیدا کند
- در پایان ۲۵ دقیقه یک صدای Completion مستقل پخش می‌شود
- خاموش کردن صدای بازی، صدای Focus را هم بلافاصله متوقف می‌کند
- تنظیمات صدا در Backup ذخیره و بازیابی می‌شوند

## خروجی GitHub Actions
`Gamification-v2.16-GameAudio.apk`
