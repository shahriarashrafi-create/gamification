# Billionaires Action — Gamification v2.17

Android gamification app with a Quest Deck, tasks, level/rank progression, Focus & Boost magic, 25-minute focus timer, achievements, statistics, backup/restore, sound effects and full Day/Night themes.

## v2.17 focus
This release is a visual safety and accessibility pass for Day/Night mode. Text contrast is strengthened across the app and responsive collision protection prevents labels, icons, badges and controls from overlapping on compact Android screens.

## GitHub build
Push the project to GitHub and run **Build Android APK**. The workflow outputs:

`Gamification-v2.17-DayNight.apk`

## Update behavior
Updating from v2.16 keeps existing game progress and settings. A fresh install starts with a clean game state.
